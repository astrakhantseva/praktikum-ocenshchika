#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Шаг 1. Инвентаризация отчёта об оценке.

Выводит число страниц, вес файла, число знаков текста на каждой странице
и наличие оглавления. Читает только указанный PDF. Файлы создаёт лишь
по явным ключам --md и --json.

Команды:
    python 01_inventory.py "Склад/Отчет.pdf"
    python 01_inventory.py "Склад/Отчет.pdf" --md "Склад/Результаты/Инвентаризация.md"
    python 01_inventory.py "Склад/Отчет.pdf" --json "Склад/Результаты/Инвентаризация.json"
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

TOC_HEAD = re.compile(r"^\s*(СОДЕРЖАНИЕ|ОГЛАВЛЕНИЕ|CONTENTS)\s*$", re.I | re.M)
TOC_LINE = re.compile(r"[._\u2026]{3,}[^\n]{0,200}?\d{1,3}\s*$", re.M)


def setup_stdout() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def read_pages(path: Path) -> tuple[list[str], int]:
    """Текст по страницам и число закладок PDF."""
    try:
        from pypdf import PdfReader
    except ImportError:  # запасной вариант
        from PyPDF2 import PdfReader  # type: ignore

    reader = PdfReader(str(path))
    texts: list[str] = []
    for page in reader.pages:
        try:
            texts.append(page.extract_text() or "")
        except Exception:
            texts.append("")
    try:
        outline = len(reader.outline)
    except Exception:
        outline = 0
    return texts, outline


def count_chars(text: str) -> int:
    return len(re.sub(r"\s+", "", text))


def toc_scan(texts: list[str]) -> dict:
    """Ищет оглавление: заголовок или строки с отточием и номером страницы."""
    pages: list[int] = []
    lines_total = 0
    started = False
    for num, text in enumerate(texts[:25], start=1):
        head = bool(TOC_HEAD.search(text))
        rows = len(TOC_LINE.findall(text))
        if head or rows >= 3:
            started = True
            pages.append(num)
            lines_total += rows
        elif started:
            break
    return {"pages": pages, "lines": lines_total, "found": bool(pages)}


def human_size(size: int) -> str:
    if size >= 1024 * 1024:
        return f"{size / 1024 / 1024:.2f} МБ"
    return f"{size / 1024:.0f} КБ"


def num(value: int) -> str:
    return f"{value:,}".replace(",", " ")


def build_report(path: Path, texts: list[str], outline: int, min_chars: int) -> dict:
    size = path.stat().st_size
    rows = []
    for num_page, text in enumerate(texts, start=1):
        chars = count_chars(text)
        rows.append(
            {
                "page": num_page,
                "chars": chars,
                "words": len(text.split()),
                "has_text": chars >= min_chars,
            }
        )
    no_text = [r["page"] for r in rows if not r["has_text"]]
    total_chars = sum(r["chars"] for r in rows)
    toc = toc_scan(texts)
    return {
        "file": str(path),
        "bytes": size,
        "size": human_size(size),
        "pages": len(texts),
        "outline": outline,
        "min_chars": min_chars,
        "toc": toc,
        "chars_total": total_chars,
        "chars_avg": round(total_chars / max(1, len(texts))),
        "pages_with_text": len(rows) - len(no_text),
        "pages_without_text": no_text,
        "rows": rows,
    }


def toc_phrase(toc: dict) -> str:
    if not toc["found"]:
        return "не найдено (проверить по первым страницам вручную)"
    pages = toc["pages"]
    span = f"стр. {pages[0]}" if len(pages) == 1 else f"стр. {pages[0]}-{pages[-1]}"
    return f"есть, {span}, строк с номером страницы: {toc['lines']}"


def render_text(rep: dict) -> str:
    out = [
        f"Файл: {rep['file']}",
        f"Вес: {rep['size']} ({num(rep['bytes'])} байт)",
        f"Страниц: {rep['pages']}",
        f"Оглавление: {toc_phrase(rep['toc'])}",
        f"PDF-закладки: {rep['outline']}",
        f"Со слоем текста: {rep['pages_with_text']}; без слоя "
        f"(знаков меньше {rep['min_chars']}): {len(rep['pages_without_text'])}",
        f"Знаков всего: {num(rep['chars_total'])}; в среднем на страницу: {num(rep['chars_avg'])}",
    ]
    if rep["pages_without_text"]:
        shown = ", ".join(str(p) for p in rep["pages_without_text"][:60])
        more = "" if len(rep["pages_without_text"]) <= 60 else " ..."
        out.append(f"Страницы без текста: {shown}{more}")
    out.append("")
    out.append("| Стр. | Знаков | Слов | Слой |")
    out.append("| ---: | ---: | ---: | :--- |")
    for row in rep["rows"]:
        out.append(
            f"| {row['page']} | {num(row['chars'])} | {num(row['words'])} | "
            f"{'есть' if row['has_text'] else 'нет'} |"
        )
    return "\n".join(out)


def render_md(rep: dict) -> str:
    head = [
        "# Инвентаризация отчёта",
        "",
        f"- Файл: `{rep['file']}`",
        f"- Вес: {rep['size']} ({num(rep['bytes'])} байт)",
        f"- Страниц: {rep['pages']}",
        f"- Оглавление: {toc_phrase(rep['toc'])}",
        f"- PDF-закладки: {rep['outline']}",
        f"- Страниц со слоем текста: {rep['pages_with_text']}, без слоя: "
        f"{len(rep['pages_without_text'])} (порог {rep['min_chars']} знаков)",
        f"- Знаков всего: {num(rep['chars_total'])}, в среднем: {num(rep['chars_avg'])}",
        "",
        "| Стр. | Знаков | Слов | Слой |",
        "| ---: | ---: | ---: | :--- |",
    ]
    rows = [
        f"| {r['page']} | {num(r['chars'])} | {num(r['words'])} | "
        f"{'есть' if r['has_text'] else 'нет'} |"
        for r in rep["rows"]
    ]
    return "\n".join(head + rows) + "\n"


def main() -> int:
    setup_stdout()
    p = argparse.ArgumentParser(description="Инвентаризация PDF-отчёта: страницы, вес, знаки, оглавление")
    p.add_argument("pdf", help="путь к PDF отчёта")
    p.add_argument("--min-chars", type=int, default=20, help="порог текстового слоя, знаков (по умолчанию 20)")
    p.add_argument("--md", help="записать таблицу в markdown-файл")
    p.add_argument("--json", help="записать данные в JSON")
    args = p.parse_args()

    path = Path(args.pdf)
    if not path.is_file():
        print(f"Файл не найден: {path}", file=sys.stderr)
        return 2

    texts, outline = read_pages(path)
    rep = build_report(path, texts, outline, args.min_chars)
    print(render_text(rep))

    if args.md:
        md_path = Path(args.md)
        md_path.parent.mkdir(parents=True, exist_ok=True)
        md_path.write_text(render_md(rep), encoding="utf-8")
        print(f"\nЗаписано: {md_path}")
    if args.json:
        js_path = Path(args.json)
        js_path.parent.mkdir(parents=True, exist_ok=True)
        js_path.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Записано: {js_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
