#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Шаг 5. Страницы без текстового слоя — картинками.

Для каждой страницы, где текста меньше порога, сохраняется PNG с именем
`<имя файла>_с<N>.png`. Сведения с таких страниц в ответе отмечаются словами
«сверить по изображению». Исходный PDF не меняется.

Команды:
    python 04_page_images.py "Склад/Отчет.pdf" --out-dir "Склад/Результаты/Изображения"
    python 04_page_images.py "Склад/Отчет.pdf" --list-only
    python 04_page_images.py "Склад/Отчет.pdf" --pages 89,91-96 --out-dir "Склад/Результаты/Изображения"
    python 04_page_images.py "Склад/Отчет.pdf" --all --dpi 200 --out-dir "Склад/Результаты/Изображения"
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


def setup_stdout() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def count_chars(text: str) -> int:
    return len(re.sub(r"\s+", "", text or ""))


def parse_pages(spec: str, total: int) -> list[int]:
    pages: set[int] = set()
    for part in re.split(r"[,\s]+", spec.strip()):
        if not part:
            continue
        m = re.fullmatch(r"(\d+)\s*-\s*(\d+)", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            pages.update(range(min(a, b), max(a, b) + 1))
        elif part.isdigit():
            pages.add(int(part))
    return sorted(p for p in pages if 1 <= p <= total)


def main() -> int:
    setup_stdout()
    p = argparse.ArgumentParser(description="Сохранение страниц без текста картинками PNG")
    p.add_argument("pdf", help="путь к PDF отчёта")
    p.add_argument("--out-dir", default=".", help="папка для PNG (по умолчанию рядом с PDF)")
    p.add_argument("--pages", help="страницы: 89,91-96 (по умолчанию — все без текста)")
    p.add_argument("--all", action="store_true", help="сохранить все страницы")
    p.add_argument("--min-chars", type=int, default=20, help="порог текстового слоя, знаков")
    p.add_argument("--dpi", type=int, default=150, help="разрешение PNG (по умолчанию 150)")
    p.add_argument("--list-only", action="store_true", help="только показать список страниц, PNG не писать")
    p.add_argument("--force", action="store_true", help="перезаписать существующие PNG")
    args = p.parse_args()

    src = Path(args.pdf)
    if not src.is_file():
        print(f"Файл не найден: {src}", file=sys.stderr)
        return 2

    import fitz  # PyMuPDF

    doc = fitz.open(str(src))
    total = doc.page_count
    if args.pages:
        targets = parse_pages(args.pages, total)
    elif args.all:
        targets = list(range(1, total + 1))
        if args.list_only:
            print(f"Страниц в файле: {total}")
    else:
        targets = [n for n in range(1, total + 1) if count_chars(doc[n - 1].get_text("text")) < args.min_chars]
        print(f"Страниц в файле: {total}; без текста (меньше {args.min_chars} знаков): {len(targets)}")
        print("Страницы: " + (", ".join(map(str, targets)) if targets else "нет"))
    doc.close()

    if args.list_only:
        return 0
    if not targets:
        print("Страниц для сохранения нет.")
        return 0

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(str(src))
    written, skipped = [], []
    for n in targets:
        dst = out_dir / f"{src.stem}_с{n}.png"
        if dst.exists() and not args.force:
            skipped.append(str(dst))
            continue
        page = doc[n - 1]
        pix = page.get_pixmap(dpi=args.dpi)
        pix.save(str(dst))
        written.append((n, dst.name, dst.stat().st_size))
    doc.close()

    for n, name, size in written:
        print(f"стр. {n}: {name} ({size // 1024} КБ)")
    if skipped:
        print(f"Уже есть, не перезаписаны: {len(skipped)}")
    print(f"\nСохранено: {len(written)}; папка: {out_dir}")
    print("Сведения с этих страниц в ответе отмечать словами «сверить по изображению».")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
