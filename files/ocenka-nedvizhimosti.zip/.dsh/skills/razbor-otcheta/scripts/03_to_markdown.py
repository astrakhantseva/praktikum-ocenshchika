#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Шаги 3 и 4. Перевод отчёта и текстов норм в Markdown.

PDF: перед каждой страницей ставится маркер [СТРАНИЦА N] с номером страницы
исходного файла, таблицы сохраняются таблицами. DOCX: заголовки, абзацы и
таблицы переводятся в Markdown; нумерация страниц в DOCX не сохраняется,
поэтому ссылки на нормы даются по номеру пункта.

Один и тот же скрипт переводит и отчёт, и файлы папки «Нормы» (шаг 4).

Команды:
    python 03_to_markdown.py "Склад/Отчет.pdf" --out "Склад/Отчет_текст.md"
    python 03_to_markdown.py "Склад/Отчет.pdf" --out "Склад/Результаты/Части/01_текст.md" --pages 2-6
    python 03_to_markdown.py "Нормы" --out-dir "Склад/Результаты/Нормы_текст"
    python 03_to_markdown.py "Нормы/ФСО 7 Оценка недвижимости.docx"
    python 03_to_markdown.py "Склад/Отчет.pdf"            # вывод в окно, файл не создаётся
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

def setup_stdout() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def norm(text: str) -> str:
    text = (text or "").replace("\u00a0", " ").replace("\u2009", " ").replace("\u200b", "")
    return re.sub(r"[ \t]+", " ", text).strip()


def cell(text: str) -> str:
    return norm(text).replace("|", "\\|")


def table_md(rows: list[list[str]]) -> str:
    rows = [[cell(c or "") for c in row] for row in (rows or [])]
    rows = [r for r in rows if any(r)]
    if not rows:
        return ""
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    keep = [j for j in range(width) if any(r[j] for r in rows)]
    if not keep:
        return ""
    rows = [[r[j] for j in keep] for r in rows]
    head, body = rows[0], rows[1:]
    out = ["| " + " | ".join(head) + " |", "| " + " | ".join("---" for _ in head) + " |"]
    out += ["| " + " | ".join(r) + " |" for r in body]
    return "\n".join(out)


def group_lines(words: list[dict], tol: float = 3.0) -> list[dict]:
    words = sorted(words, key=lambda w: (round(w["top"], 1), w["x0"]))
    lines: list[dict] = []
    for w in words:
        if lines:
            line = lines[-1]
            if abs(line["top"] - w["top"]) <= tol and w["x0"] >= line["x1"] - 2:
                gap = w["x0"] - line["x1"]
                space = " " if gap > 0.18 * max(line["h"], 6) else ""
                line["text"] += space + w["text"]
                line["x1"] = max(line["x1"], w["x1"])
                continue
        lines.append({"top": w["top"], "x1": w["x1"], "h": w.get("height", 10), "text": w["text"]})
    for line in lines:
        line["text"] = norm(line["text"])
    return [line for line in lines if line["text"]]


def heading(text: str) -> str | None:
    s = text.strip()
    if not (4 <= len(s) <= 180):
        return None
    letters = [c for c in s if c.isalpha()]
    if not letters:
        return None
    caps = sum(1 for c in letters if c.isupper()) / len(letters)
    if re.match(r"^ПРИЛОЖЕНИЕ\b", s, re.I):
        return "## " + s
    m = re.match(r"^(\d+(?:\.\d+)*)\.?\s+\S", s)
    if m and caps >= 0.6:
        return ("## " if m.group(1).count(".") == 0 else "### ") + s
    return None


def render_pdf_page(page, with_tables: bool = True) -> tuple[str, int]:
    words = page.extract_words(keep_blank_chars=False, use_text_flow=False)
    found: list[dict] = []
    if with_tables:
        try:
            tables = page.find_tables()
        except Exception:
            tables = []
        for table in tables:
            try:
                md = table_md(table.extract())
            except Exception:
                md = ""
            if md and table.bbox:
                found.append({"bbox": table.bbox, "top": table.bbox[1], "md": md})

    def inside(word: dict, box) -> bool:
        cx = (word["x0"] + word["x1"]) / 2.0
        cy = (word["top"] + word["bottom"]) / 2.0
        return box[0] - 1 <= cx <= box[2] + 1 and box[1] - 1 <= cy <= box[3] + 1

    free = [w for w in words if not any(inside(w, t["bbox"]) for t in found)]
    lines = group_lines(free)

    elements: list[tuple[float, int, str, float]] = []
    for table in found:
        elements.append((float(table["top"]), 0, table["md"], 10.0))
    for line in lines:
        text = line["text"]
        head = heading(text)
        elements.append((float(line["top"]), 1, head or text, float(line["h"] or 10)))
    elements.sort(key=lambda e: (round(e[0], 1), e[1]))

    out: list[str] = []
    prev_top, prev_h = None, 10.0
    for top, kind, value, height in elements:
        if prev_top is not None and top - prev_top > 1.7 * max(prev_h, 8):
            out.append("")
        out.append(value)
        prev_top, prev_h = top, height if height else prev_h
    return "\n".join(out).strip(), len(found)


def parse_pages(spec: str, total: int) -> list[int]:
    pages: set[int] = set()
    for part in re.split(r"[,\s]+", spec.strip()):
        if not part:
            continue
        m = re.fullmatch(r"(\d+)\s*-\s*(\d+)", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            pages.update(range(min(a, b), max(a, b) + 1))
        elif part.isdigit():
            pages.add(int(part))
    return sorted(p for p in pages if 1 <= p <= total)


def convert_pdf(path: Path, pages_spec: str | None, with_tables: bool) -> tuple[str, dict]:
    import pdfplumber

    blocks: list[str] = []
    stats = {"pages": 0, "tables": 0, "chars": 0}
    with pdfplumber.open(str(path)) as pdf:
        total = len(pdf.pages)
        selected = parse_pages(pages_spec, total) if pages_spec else list(range(1, total + 1))
        for pno in selected:
            body, tables = render_pdf_page(pdf.pages[pno - 1], with_tables)
            stats["pages"] += 1
            stats["tables"] += tables
            stats["chars"] += len(re.sub(r"\s+", "", body))
            blocks.append(f"[СТРАНИЦА {pno}]\n\n{body}".rstrip())
    header = (
        f"> Источник: `{path}`. Маркер [СТРАНИЦА N] — страница N исходного PDF.\n"
        f"> Страниц в выгрузке: {stats['pages']}; таблиц: {stats['tables']}; "
        f"знаков: {stats['chars']}.\n"
    )
    return header + "\n" + "\n\n".join(blocks) + "\n", stats


def docx_to_md(path: Path) -> tuple[str, dict]:
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    doc = Document(str(path))
    parts: list[str] = []
    stats = {"paragraphs": 0, "tables": 0, "chars": 0}
    body = doc.element.body
    for child in body.iterchildren():
        tag = child.tag.split("}")[-1]
        if tag == "p":
            par = Paragraph(child, doc)
            text = norm(par.text)
            if not text:
                continue
            style = (par.style.name or "").lower()
            stats["paragraphs"] += 1
            stats["chars"] += len(re.sub(r"\s+", "", text))
            if style.startswith("heading"):
                m = re.search(r"(\d+)", style)
                level = min(int(m.group(1)) if m else 1, 6)
                parts.append("#" * level + " " + text)
            elif style.startswith("list"):
                parts.append("- " + text)
            else:
                parts.append(text)
        elif tag == "tbl":
            table = Table(child, doc)
            rows = [[norm(c.text) for c in row.cells] for row in table.rows]
            md = table_md(rows)
            if md:
                stats["tables"] += 1
                parts.append(md)
    header = (
        f"> Источник: `{path}`. Нумерация страниц в DOCX не сохраняется: "
        f"ссылки на нормы даются по номеру пункта.\n"
    )
    return header + "\n" + "\n\n".join(parts) + "\n", stats


def output_path(src: Path, args) -> Path | None:
    if args.out:
        return Path(args.out)
    if args.out_dir:
        return Path(args.out_dir) / f"{src.stem}_текст.md"
    return None


def main() -> int:
    setup_stdout()
    p = argparse.ArgumentParser(description="Перевод PDF и DOCX в Markdown с маркером [СТРАНИЦА N]")
    p.add_argument("paths", nargs="+", help="файлы или папки (PDF, DOCX)")
    p.add_argument("--out", help="файл результата для одиночного входа")
    p.add_argument("--out-dir", help="папка для файлов <имя>_текст.md")
    p.add_argument("--pages", help="страницы PDF: 2-6,9 (по умолчанию все)")
    p.add_argument("--no-tables", action="store_true", help="не выделять таблицы, только текст")
    p.add_argument("--print", dest="to_stdout", action="store_true", help="печатать результат в окно")
    args = p.parse_args()

    files: list[Path] = []
    for raw in args.paths:
        path = Path(raw)
        if path.is_dir():
            files += sorted([f for f in path.iterdir() if f.suffix.lower() in {".pdf", ".docx"}])
        elif path.is_file():
            files.append(path)
        else:
            print(f"Пропущено, не найдено: {path}", file=sys.stderr)
    if not files:
        print("Нет файлов для перевода.", file=sys.stderr)
        return 2
    if args.out and len(files) > 1:
        print("Ключ --out допустим только для одного файла, для папки используйте --out-dir.", file=sys.stderr)
        return 2

    for src in files:
        if src.suffix.lower() == ".pdf":
            text, stats = convert_pdf(src, args.pages, not args.no_tables)
        elif src.suffix.lower() == ".docx":
            text, stats = docx_to_md(src)
        else:
            print(f"Пропущено, не PDF и не DOCX: {src}", file=sys.stderr)
            continue

        dst = output_path(src, args)
        if dst and not args.to_stdout:
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_text(text, encoding="utf-8")
            print(f"{src} -> {dst} ({len(text)} знаков, {stats})")
        else:
            print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
