#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Шаг 2. Карта отчёта по оглавлению и разбивка файла на части.

Карта: раздел или приложение и его страницы. Разбивка: раздел верхнего
уровня — отдельный PDF, каждое приложение — отдельным файлом, начало
отчёта (титул и оглавление) — отдельным файлом. Исходный PDF не меняется.

Команды:
    python 02_map_split.py "Склад/Отчет.pdf"
    python 02_map_split.py "Склад/Отчет.pdf" --map-out "Склад/Результаты/Карта_отчета.md"
    python 02_map_split.py "Склад/Отчет.pdf" --map-out "Склад/Результаты/Карта_отчета.md" \
        --split-out "Склад/Результаты/Части"
    python 02_map_split.py "Склад/Отчет.pdf" --map "Склад/Результаты/Карта_отчета.md" \
        --split-out "Склад/Результаты/Части"      # разбивка по правленой вручную карте
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

TOC_HEAD = re.compile(r"^\s*(СОДЕРЖАНИЕ|ОГЛАВЛЕНИЕ|CONTENTS)\s*$", re.I | re.M)
TOC_LINE = re.compile(r"[._\u2026]{3,}[^\n]{0,200}?\d{1,3}\s*$", re.M)
ANNEX_RE = re.compile(r"^ПРИЛОЖЕНИЕ\b", re.I)
NUM_RE = re.compile(r"^(\d+(?:\.\d+)*)\.?\s")


def setup_stdout() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def read_pages_text(path: Path) -> list[str]:
    try:
        from pypdf import PdfReader
    except ImportError:
        from PyPDF2 import PdfReader  # type: ignore

    reader = PdfReader(str(path))
    texts: list[str] = []
    for page in reader.pages:
        try:
            texts.append(page.extract_text() or "")
        except Exception:
            texts.append("")
    return texts


def find_toc_pages(texts: list[str]) -> list[int]:
    pages: list[int] = []
    started = False
    for num, text in enumerate(texts[:25], start=1):
        rows = len(TOC_LINE.findall(text))
        if TOC_HEAD.search(text) or rows >= 3:
            started = True
            pages.append(num)
        elif started:
            break
    return pages


def clean_line(line: str) -> str:
    s = line.replace("\u00a0", " ")
    s = re.sub(r"[._\u2026]{2,}", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def parse_entries(texts: list[str], toc_pages: list[int], total: int) -> tuple[list[dict], list[str]]:
    """Строки оглавления -> записи {title, page}. Возвращает записи и нераспознанное."""
    entries: list[dict] = []
    skipped: list[str] = []
    buf: list[str] = []
    for pno in toc_pages:
        for raw in texts[pno - 1].splitlines():
            s = raw.strip()
            if not s or re.fullmatch(r"\d{1,3}", s) or TOC_HEAD.match(s):
                continue
            core = clean_line(s)
            if not core or len(core) < 2:
                continue
            m = re.match(r"^(.*?)\s+(\d{1,3})$", core)
            if m and len(m.group(1)) >= 3:
                title = " ".join(buf + [m.group(1)]).strip()
                buf = []
                page = int(m.group(2))
                if 1 <= page <= total:
                    entries.append({"title": title, "page": page})
                else:
                    skipped.append(core)
                continue
            buf.append(core)
    if buf:
        skipped.extend(buf)
    # склейка записей, разорванных переносом внутри названия
    merged: list[dict] = []
    for e in entries:
        if merged and merged[-1]["page"] == e["page"] and not NUM_RE.match(e["title"]):
            merged[-1]["title"] += " " + e["title"]
        else:
            merged.append(dict(e))
    return merged, skipped


def classify(title: str) -> tuple[str, int]:
    t = title.strip()
    if ANNEX_RE.match(t):
        return "annex", 0
    m = NUM_RE.match(t)
    if m:
        return "section", m.group(1).count(".") + 1
    return "section", 1


def build_rows(entries: list[dict], total: int) -> list[dict]:
    rows: list[dict] = []
    for i, e in enumerate(entries):
        kind, level = classify(e["title"])
        start = e["page"]
        stop = total
        for nxt in entries[i + 1:]:
            if nxt["page"] > start:
                stop = nxt["page"] - 1
                break
        if stop < start:
            stop = start
        rows.append(
            {
                "n": i + 1,
                "title": e["title"],
                "kind": kind,
                "level": level,
                "start": start,
                "stop": stop,
                "pages": stop - start + 1,
            }
        )
    return rows


def top_groups(rows: list[dict], total: int) -> list[dict]:
    tops = [r for r in rows if r["kind"] == "annex" or r["level"] <= 1]
    if not tops:
        tops = rows
    groups: list[dict] = []
    for i, r in enumerate(tops):
        if r["kind"] == "annex":
            stop = total
            if i + 1 < len(tops):
                stop = tops[i + 1]["start"] - 1
            groups.append({**r, "gstart": r["start"], "gstop": max(stop, r["start"])})
        else:
            stop = total
            nxt = next((t for t in tops[i + 1:]), None)
            if nxt:
                stop = nxt["start"] - 1
            groups.append({**r, "gstart": r["start"], "gstop": max(stop, r["start"])})
    first = groups[0]["gstart"] if groups else 1
    if first > 1:
        groups.insert(0, {"n": 0, "title": "Начало отчёта (титул и оглавление)", "kind": "front",
                          "level": 0, "start": 1, "stop": first - 1, "pages": first - 1,
                          "gstart": 1, "gstop": first - 1})
    return groups


def slug(title: str, limit: int = 46) -> str:
    s = re.sub(r"^[\d.)\s]+", "", title.strip())
    s = re.sub(r"[^\w\s\-А-Яа-яЁё]", " ", s, flags=re.U)
    s = re.sub(r"\s+", "_", s.strip(" _"))
    return (s[:limit].strip("_") or "часть")


def part_name(group: dict, idx: int, total: int) -> str:
    tag = "прил" if group["kind"] == "annex" else ("начало" if group["kind"] == "front" else "разд")
    return f"{idx:02d}_{tag}_{slug(group['title'])}_с{group['gstart']}-{group['gstop']}.pdf"


def render_map(rows: list[dict], groups: list[dict], path: Path, total: int,
               toc_pages: list[int], skipped: list[str]) -> str:
    annexes = [r for r in rows if r["kind"] == "annex"]
    sections = [r for r in rows if r["kind"] != "annex"]
    order_broken = any(rows[i]["start"] > rows[i + 1]["start"] for i in range(len(rows) - 1))
    toc_span = "нет" if not toc_pages else (
        f"стр. {toc_pages[0]}" if len(toc_pages) == 1 else f"стр. {toc_pages[0]}-{toc_pages[-1]}"
    )
    out = [
        "# Карта отчета",
        "",
        f"- Файл: `{path}`",
        f"- Страниц в файле: {total}",
        f"- Оглавление отчёта: {toc_span}",
        f"- Записей в карте: {len(rows)} (разделов {len(sections)}, приложений {len(annexes)})",
        f"- Нумерация страниц: {'нарушена, проверить' if order_broken else 'по возрастанию'}",
        "",
        "## Разделы и приложения",
        "",
        "| № | Ур. | Раздел или приложение | Стр. с | Стр. по | Листов |",
        "| ---: | :--- | :--- | ---: | ---: | ---: |",
    ]
    for r in rows:
        lvl = "прил." if r["kind"] == "annex" else str(r["level"])
        out.append(
            f"| {r['n']} | {lvl} | {r['title'].replace('|', '/')} | {r['start']} | {r['stop']} | {r['pages']} |"
        )
    out += ["", "## Части для разбивки", "",
            "| Часть | Стр. с | Стр. по | Листов | Имя файла |",
            "| ---: | ---: | ---: | ---: | :--- |"]
    for i, g in enumerate(groups, start=1):
        out.append(
            f"| {i} | {g['gstart']} | {g['gstop']} | {g['gstop'] - g['gstart'] + 1} | "
            f"{part_name(g, i, total)} |"
        )
    if skipped:
        out += ["", "## Не распознано в оглавлении (проверить вручную)", ""]
        out += [f"- {s}" for s in skipped[:40]]
    out += ["", "## Как править карту", "",
            "Названия и номера страниц правятся прямо в таблице «Разделы и приложения»; "
            "после правки разбивка выполняется с ключом `--map` по этому файлу.", ""]
    return "\n".join(out)


def read_map(path: Path) -> tuple[list[dict], int]:
    """Читает правленую карту: строки таблицы «Раздел | Стр. с | Стр. по»."""
    rows: list[dict] = []
    total = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^\s*-\s*Страниц в файле:\s*(\d+)", line)
        if m:
            total = int(m.group(1))
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 6 or not cells[0].isdigit():
            continue
        if cells[1] == "Ур." or set(cells[1]) <= {"-", ":"}:
            continue
        try:
            start, stop = int(cells[3]), int(cells[4])
        except ValueError:
            continue
        kind = "annex" if cells[1].startswith("прил") else "section"
        level = 0 if kind == "annex" else (int(cells[1]) if cells[1].isdigit() else 1)
        rows.append({"n": int(cells[0]), "title": cells[2], "kind": kind, "level": level,
                     "start": start, "stop": stop, "pages": stop - start + 1})
    return rows, total


def split_pdf(src: Path, groups: list[dict], out_dir: Path, total: int) -> list[str]:
    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError:
        from PyPDF2 import PdfReader, PdfWriter  # type: ignore

    reader = PdfReader(str(src))
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    for i, g in enumerate(groups, start=1):
        name = part_name(g, i, total)
        dst = out_dir / name
        writer = PdfWriter()
        for pno in range(g["gstart"] - 1, min(g["gstop"], total)):
            writer.add_page(reader.pages[pno])
        with dst.open("wb") as fh:
            writer.write(fh)
        written.append(f"{name} — стр. {g['gstart']}-{g['gstop']}")
    return written


def main() -> int:
    setup_stdout()
    p = argparse.ArgumentParser(description="Карта отчёта по оглавлению и разбивка PDF на части")
    p.add_argument("pdf", help="путь к PDF отчёта")
    p.add_argument("--map-out", help="записать карту в markdown-файл")
    p.add_argument("--map", help="готовая (правленая) карта для разбивки")
    p.add_argument("--split-out", help="папка для частей PDF")
    p.add_argument("--toc-pages", help="страницы оглавления через запятую, если не распознаны")
    args = p.parse_args()

    src = Path(args.pdf)
    if not src.is_file():
        print(f"Файл не найден: {src}", file=sys.stderr)
        return 2

    skipped: list[str] = []
    toc_pages: list[int] = []
    if args.map:
        rows, total = read_map(Path(args.map))
        if not rows:
            print(f"В карте не найдено ни одной строки: {args.map}", file=sys.stderr)
            return 3
    else:
        texts = read_pages_text(src)
        total = len(texts)
        if args.toc_pages:
            toc_pages = [int(x) for x in re.split(r"[,\s]+", args.toc_pages.strip()) if x.isdigit()]
        else:
            toc_pages = find_toc_pages(texts)
        if not toc_pages:
            print("Оглавление не найдено. Укажите страницы ключом --toc-pages или соберите карту вручную.",
                  file=sys.stderr)
            return 4
        entries, skipped = parse_entries(texts, toc_pages, total)
        if not entries:
            print("В оглавлении не распознано ни одной записи с номером страницы.", file=sys.stderr)
            return 4
        rows = build_rows(entries, total)

    groups = top_groups(rows, total)
    md = render_map(rows, groups, src, total, toc_pages, skipped)
    if args.map_out and not args.map:
        dst = Path(args.map_out)
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(md, encoding="utf-8")
        print(f"Карта записана: {dst}")
    else:
        print(md)

    if args.split_out:
        written = split_pdf(src, groups, Path(args.split_out), total)
        print(f"\nЧастей: {len(written)}; папка: {args.split_out}")
        for line in written:
            print(f"  {line}")
    else:
        print(f"\nЧастей к разбивке: {len(groups)} (файлы не создавались, нужен ключ --split-out)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
