#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сценарный расчет по готовому расчетному файлу об оценке.

Команды:
  backup  — сохранить копию расчетного файла с датой в имени;
  build   — добавить (пересобрать) лист «Сценарии», не меняя исходные листы;
  recalc  — пересчитать книгу в LibreOffice;
  check   — проверить формулы, сверку якорей, сортировку размаха и оси
            таблиц чувствительности.

Пути по умолчанию:
  данные — .dsh/skills/scenarii/data/scenarios.json
  книга  — Склад/Результаты/Расчетный файл по складу.xlsx

Правила работы: исходный расчет не меняется; числа записываются только
в желтые ячейки входа листа «Сценарии»; расчетные ячейки — формулы.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Iterable

from openpyxl import load_workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter, range_boundaries
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.properties import PageSetupProperties

SKILL_DIR = Path(__file__).resolve().parent.parent
DEFAULT_DATA = SKILL_DIR / "data" / "scenarios.json"
DEFAULT_FILE = Path("Склад/Результаты/Расчетный файл по складу.xlsx")

SHEET = "Сценарии"

# ---------------------------------------------------------------------------
# Стили
# ---------------------------------------------------------------------------

FONT = "Calibri"
CLR_HEADER = "1F4E79"
CLR_SECTION = "D9E2F3"
CLR_INPUT = "FFF2CC"
CLR_REPORT = "E7E6E6"
CLR_CHECK = "E2EFDA"
CLR_BAD = "F8CBAD"
CLR_WHITE = "FFFFFF"

THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

FMT_RUB = "#,##0"
FMT_RUB2 = "#,##0.00"
FMT_PCT = "0.00%"
FMT_COEF = "0.000"
FMT_AREA = "#,##0.0"

# ---------------------------------------------------------------------------
# Разметка листа «Сценарии» (адреса постоянны: лист пересобирается целиком)
# ---------------------------------------------------------------------------

R_SEL = 6
R_SHIFT = 7
R_STATUS = 8

R_BOUND_SEC = 10
R_BOUND_HDR = 11
R_BOUNDS = {
    "load_lower": 12,
    "load_upper": 13,
    "opex_lower": 14,
    "opex_upper": 15,
    "rent_lower": 16,
    "rent_upper": 17,
    "cap_base": 18,
}

R_PARAM_SEC = 20
R_PARAM_HDR = 21
R_PARAMS = {"rent": 23, "load": 24, "opex": 25, "cap": 26}

R_MODEL_SEC = 28
R_MODEL_HDR = 29
R_MODEL = 30  # 30..44

R_RECON_SEC = 46
R_RECON_HDR = 47
R_RECON = 48  # 48..60

R_SUM_SEC = 62
R_SUM_HDR = 63
R_SUM = 64  # 64..67

R_ANCHOR_SEC = 69
R_ANCHOR_HDR = 70
R_ANCHORS = 71  # 71..73

R_SWING_SEC = 75
R_SWING_HDR = 76
R_SWING = 77  # 77..80

R_ORDER_SEC = 82
R_ORDER_HDR = 83
R_ORDER = 84  # 84..87

R_SENS1_SEC = 89
R_SENS1_HDR = 90
R_SENS1 = 91  # 91..95

R_SENS2_SEC = 97
R_SENS2_HDR = 98
R_SENS2 = 99  # 99..103

R_NOTE_SEC = 105
R_NOTES = 106

LAST_COL = 16  # P
COL_LETTERS = tuple(get_column_letter(i) for i in range(1, LAST_COL + 1))

ALLOWED_NUMERIC = {"D6", "D7", "D12", "D13", "D14", "D15"}

# ---------------------------------------------------------------------------
# Общие помощники
# ---------------------------------------------------------------------------


def fail(message: str) -> None:
    raise SystemExit(f"ошибка: {message}")


def text(value: Any) -> str:
    if value is None:
        return ""
    return " ".join(str(value).replace("\u00a0", " ").split())


def load_data(path: Path) -> dict:
    if not path.exists():
        fail(f"нет файла данных: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def put(
    ws,
    ref: str,
    value: Any,
    *,
    bold: bool = False,
    italic: bool = False,
    size: int = 10,
    color: str = "000000",
    fill_color: str | None = None,
    fmt: str | None = None,
    wrap: bool = False,
    h: str | None = None,
    border: bool = True,
):
    c = ws[ref]
    c.value = value
    c.font = Font(name=FONT, bold=bold, italic=italic, size=size, color=color)
    c.alignment = Alignment(horizontal=h, vertical="center", wrap_text=wrap)
    if border:
        c.border = BORDER
    if fill_color:
        c.fill = PatternFill("solid", fgColor=fill_color)
    if fmt:
        c.number_format = fmt
    return c


def section(ws, row: int, title: str) -> None:
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=LAST_COL)
    c = ws.cell(row=row, column=1, value=title)
    c.font = Font(name=FONT, bold=True, size=11, color=CLR_HEADER)
    c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    for col in range(1, LAST_COL + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = PatternFill("solid", fgColor=CLR_SECTION)
        cell.border = BORDER
    ws.row_dimensions[row].height = 22


def header(ws, row: int, values: list[str]) -> None:
    for i, value in enumerate(values, start=1):
        c = ws.cell(row=row, column=i, value=value)
        c.font = Font(name=FONT, bold=True, size=9, color=CLR_WHITE)
        c.fill = PatternFill("solid", fgColor=CLR_HEADER)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = BORDER
    ws.row_dimensions[row].height = 34


def merge_note(ws, row: int, first_col: int, last_col: int, value: str) -> None:
    ws.merge_cells(start_row=row, start_column=first_col, end_row=row, end_column=last_col)
    c = ws.cell(row=row, column=first_col, value=value)
    c.font = Font(name=FONT, italic=True, size=9, color="404040")
    c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)


def cell_text_at(ws, row: int, col: int = 2) -> str:
    return text(ws.cell(row=row, column=col).value)


def find_label_row(ws, prefix: str, col: int = 2) -> int | None:
    for r in range(1, ws.max_row + 1):
        if cell_text_at(ws, r, col).startswith(prefix):
            return r
    return None


def find_exact_row(ws, label: str, col: int = 2) -> int | None:
    for r in range(1, ws.max_row + 1):
        if cell_text_at(ws, r, col) == label:
            return r
    return None


# ---------------------------------------------------------------------------
# Чтение расчетного файла: входы, якоря, ставки аренды
# ---------------------------------------------------------------------------


def locate_inputs(wb) -> dict[str, int]:
    if "Вход" not in wb.sheetnames:
        fail("в книге нет листа «Вход»: это не расчетный файл навыка raschetnyj-fajl")
    ws = wb["Вход"]
    codes: dict[str, int] = {}
    for r in range(1, ws.max_row + 1):
        code = cell_text_at(ws, r)
        if re.fullmatch(r"I_[A-Z0-9_]+", code):
            codes[code] = r
    need = [
        "I_AREA",
        "I_RENTABLE_COEF",
        "I_LAND_SHARE",
        "I_VACANCY",
        "I_OPEX",
        "I_CAP_RATE",
        "I_WEIGHT_SALE_COMP",
        "I_WEIGHT_SALE_INC",
        "I_WEIGHT_COST",
    ]
    missing = [code for code in need if code not in codes]
    if missing:
        fail("на листе «Вход» нет кодов: " + ", ".join(missing))
    return codes


def locate_anchors(wb) -> dict[str, int]:
    if "Расчет" not in wb.sheetnames:
        fail("в книге нет листа «Расчет»")
    ws = wb["Расчет"]
    labels = {
        "income": "Рыночная стоимость ОКС (доходный подход)",
        "comparative": "Рыночная стоимость ОКС (сравнительный подход)",
        "cost": "Рыночная стоимость ОКС (затратный подход)",
        "final": "Итоговая стоимость (округленно)",
    }
    found: dict[str, int] = {}
    for r in range(1, ws.max_row + 1):
        label = cell_text_at(ws, r)
        for key, wanted in labels.items():
            if key in found or label != wanted:
                continue
            value = ws.cell(row=r, column=4).value
            if not (isinstance(value, str) and value.startswith("=")):
                fail(f"«Расчет»!D{r} («{wanted}») не формула: расчетный файл собран не по правилам")
            found[key] = r
    missing = [labels[key] for key in labels if key not in found]
    if missing:
        fail("на листе «Расчет» не найдены строки: " + "; ".join(missing))
    return found


def locate_rent_adjusted_row(wb) -> int:
    if "Аренда" not in wb.sheetnames:
        fail("в книге нет листа «Аренда»")
    ws = wb["Аренда"]
    avg_row = find_label_row(ws, "Средневзвешенное значение")
    if not avg_row:
        fail("на листе «Аренда» нет строки «Средневзвешенное значение»")
    for r in range(avg_row - 1, 0, -1):
        if cell_text_at(ws, r) != "Скорректированная цена, руб./кв.м":
            continue
        values = [ws.cell(row=r, column=c).value for c in (5, 6, 7)]
        if all(isinstance(v, str) and v.startswith("=") for v in values):
            return r
    fail("на листе «Аренда» не найдена последняя строка скорректированных ставок")


def input_ref(codes: dict[str, int], code: str) -> str:
    return f"'Вход'!$F${codes[code]}"


def input_literal(wb, codes: dict[str, int], code: str) -> float | None:
    value = wb["Вход"].cell(row=codes[code], column=6).value
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    return None


# ---------------------------------------------------------------------------
# Формулы
# ---------------------------------------------------------------------------


def oks_formula(rate: str, load: str, opex: str, cap: str) -> str:
    """Стоимость ОКС по доходному подходу теми же округлениями, что на «Расчет»."""
    pvd = "ROUND($G$32*({}*12),0)".format(rate)
    return (
        f"=ROUND(ROUND((ROUND({pvd}*{load},0)-ROUND({pvd}*{opex},0))/{cap},0)"
        f"*(1-$G$43),0)"
    )


# ---------------------------------------------------------------------------
# Сборка листа
# ---------------------------------------------------------------------------


def build_sheet(
    wb,
    data: dict,
    *,
    selector: int,
    shift: float,
    bounds_values: dict[str, float],
    anchors: dict[str, int],
    codes: dict[str, int],
    rent_row: int,
) -> None:
    pos = wb.sheetnames.index("Расчет") + 1
    ws = wb.create_sheet(SHEET, pos)
    ws.sheet_view.showGridLines = False
    widths = {
        "A": 6, "B": 56, "C": 15, "D": 16, "E": 16, "F": 16, "G": 16,
        "H": 16, "I": 42, "J": 13, "K": 9, "L": 42, "M": 13, "N": 9,
        "O": 8, "P": 44,
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    meta = data["meta"]
    # Титул
    ws.merge_cells("A1:P1")
    put(ws, "A1", "СЦЕНАРИИ — доходный подход и согласование при разной загрузке "
                  "и операционных расходах", bold=True, size=14, color=CLR_WHITE,
        fill_color=CLR_HEADER, border=False)
    ws.row_dimensions[1].height = 26
    ws.merge_cells("A2:P2")
    put(ws, "A2", f"{meta.get('object', '')}. Исходный расчет не меняется: лист только "
                  f"читает «Вход», «Аренда» и «Расчет».", italic=True, size=9,
        color="404040", border=False, wrap=True)
    ws.row_dimensions[2].height = 28
    ws.merge_cells("A3:P3")
    put(ws, "A3", "Сценарий выбирается ячейкой D6: 1 — неблагоприятный, 2 — базовый "
                  "(принятый в отчете), 3 — благоприятный. Значения активного сценария "
                  "берутся формулой ВЫБОР.", italic=True, size=9, color="404040",
        border=False, wrap=True)
    ws.row_dimensions[3].height = 28

    # 0. Параметры правки
    section(ws, R_SEL - 1, "0. Параметры правки (желтые ячейки)")
    put(ws, f"B{R_SEL}", "Номер активного сценария: 1 — неблагоприятный, 2 — базовый, "
                         "3 — благоприятный", wrap=True, h="left")
    put(ws, f"D{R_SEL}", int(selector), bold=True, size=12, fill_color=CLR_INPUT,
        h="center", fmt="0")
    merge_note(ws, R_SEL, 5, LAST_COL,
               "1 — худший для собственника, 2 — принятый в отчете, 3 — лучший. "
               "Все значения активного сценария считаются ВЫБОР по этой ячейке.")
    ws.row_dimensions[R_SEL].height = 30

    put(ws, f"B{R_SHIFT}", "Сдвиг ставки капитализации вниз и вверх, п.п.", wrap=True,
        h="left")
    put(ws, f"D{R_SHIFT}", float(shift), bold=True, fill_color=CLR_INPUT, h="center",
        fmt=FMT_PCT)
    merge_note(ws, R_SHIFT, 5, LAST_COL,
               "Ставка капитализации во всех сценариях равна ставке отчета; сдвиг "
               "применяется только в размахе влияния и таблицах чувствительности. "
               "Граница в отчете не приведена.")
    ws.row_dimensions[R_SHIFT].height = 30

    put(ws, f"B{R_STATUS}", "Состояние сверки якорей", wrap=True, h="left")
    put(ws, f"D{R_STATUS}",
        f'=IF($D${R_SEL}=2,"сценарий 2 — сверка действительна",'
        f'"сценарий "&$D${R_SEL}&" — сверка недействительна, верните 2")',
        bold=True, fill_color=CLR_CHECK, h="center")
    ws.merge_cells(start_row=R_STATUS, start_column=5, end_row=R_STATUS,
                   end_column=LAST_COL)
    put(ws, f"E{R_STATUS}",
        "Разность модели и расчетного файла по доходному подходу и итогу ожидаема "
        "при сценарии, отличном от базового.", italic=True, size=9, color="404040",
        border=False, wrap=True)

    # 1. Границы параметров
    section(ws, R_BOUND_SEC, "1. Границы параметров из таблиц отчета "
                             "(у каждой границы — источник, таблица и страница)")
    header(ws, R_BOUND_HDR, ["№", "Параметр", "Ед. изм.", "Значение", "Источник",
                             "Таблица отчета", "Стр. отчета", "Примечание"])
    bounds = {b["key"]: b for b in data["bounds"]}
    order = ["load_lower", "load_upper", "opex_lower", "opex_upper",
             "rent_lower", "rent_upper", "cap_base"]
    for i, key in enumerate(order, start=1):
        b = bounds[key]
        r = R_BOUNDS[key]
        put(ws, f"A{r}", i, h="center")
        put(ws, f"B{r}", b["label"], wrap=True, h="left")
        put(ws, f"C{r}", b.get("unit", ""), h="center")
        fmt = FMT_PCT if b.get("unit") == "доля" else FMT_RUB2
        if "value" in b:
            value = bounds_values.get(key, float(b["value"]))
            put(ws, f"D{r}", float(value), fill_color=CLR_INPUT, h="center", fmt=fmt)
        elif b.get("formula") == "min_rent":
            put(ws, f"D{r}", f"=MIN('Аренда'!$E${rent_row}:$G${rent_row})",
                fill_color=CLR_CHECK, h="center", fmt=fmt)
        elif b.get("formula") == "max_rent":
            put(ws, f"D{r}", f"=MAX('Аренда'!$E${rent_row}:$G${rent_row})",
                fill_color=CLR_CHECK, h="center", fmt=fmt)
        elif b.get("formula") == "input_cap":
            put(ws, f"D{r}", "=" + input_ref(codes, "I_CAP_RATE"),
                fill_color=CLR_CHECK, h="center", fmt=fmt)
        else:
            fail(f"неизвестная граница {key}")
        put(ws, f"E{r}", b.get("source", ""), wrap=True, h="left", size=9)
        put(ws, f"F{r}", b.get("table", "—"), h="center")
        put(ws, f"G{r}", b.get("page", "—"), h="center")
        put(ws, f"H{r}", b.get("note", ""), wrap=True, h="left", size=9)
        ws.row_dimensions[r].height = 36

    # 2. Значения параметров по сценариям
    section(ws, R_PARAM_SEC, "2. Значения параметров по сценариям "
                             "(активный — формулой ВЫБОР)")
    header(ws, R_PARAM_HDR, ["№", "Параметр", "Ед. изм.",
                             "Сценарий 1 — неблагоприятный",
                             "Сценарий 2 — базовый",
                             "Сценарий 3 — благоприятный",
                             "Активный сценарий (ВЫБОР)",
                             "Нижняя граница", "Верхняя граница",
                             "Источник базового значения", "Примечание"])
    scenario_values: dict[str, list[str]] = {
        "rent": ["='Вход'!$D$8", "='Вход'!$D$8", "='Вход'!$D$8"],
        "load": [f"=$D${R_BOUNDS['load_lower']}",
                 f"=1-{input_ref(codes, 'I_VACANCY')}",
                 f"=$D${R_BOUNDS['load_upper']}"],
        "opex": [f"=$D${R_BOUNDS['opex_upper']}",
                 "=" + input_ref(codes, "I_OPEX"),
                 f"=$D${R_BOUNDS['opex_lower']}"],
        "cap": ["=" + input_ref(codes, "I_CAP_RATE"),
                "=" + input_ref(codes, "I_CAP_RATE"),
                "=" + input_ref(codes, "I_CAP_RATE")],
    }
    bound_refs = {
        "rent": (f"=$D${R_BOUNDS['rent_lower']}", f"=$D${R_BOUNDS['rent_upper']}"),
        "load": (f"=$D${R_BOUNDS['load_lower']}", f"=$D${R_BOUNDS['load_upper']}"),
        "opex": (f"=$D${R_BOUNDS['opex_lower']}", f"=$D${R_BOUNDS['opex_upper']}"),
        "cap": (f"=$D${R_BOUNDS['cap_base']}-$D${R_SHIFT}",
                f"=$D${R_BOUNDS['cap_base']}+$D${R_SHIFT}"),
    }
    param_notes = {p["key"]: p for p in data["parameters"]}
    for i, key in enumerate(["rent", "load", "opex", "cap"], start=1):
        p = param_notes[key]
        r = R_PARAMS[key]
        put(ws, f"A{r}", i, h="center")
        put(ws, f"B{r}", p["label"], wrap=True, h="left")
        put(ws, f"C{r}", p.get("unit", ""), h="center")
        fmt = FMT_PCT if p.get("unit") == "доля" else FMT_RUB2
        for col, formula in zip(("D", "E", "F"), scenario_values[key]):
            put(ws, f"{col}{r}", formula, h="center", fmt=fmt)
        put(ws, f"G{r}", f"=CHOOSE($D${R_SEL},D{r},E{r},F{r})", bold=True,
            fill_color=CLR_CHECK, h="center", fmt=fmt)
        put(ws, f"H{r}", bound_refs[key][0], h="center", fmt=fmt)
        put(ws, f"I{r}", bound_refs[key][1], h="center", fmt=fmt)
        put(ws, f"J{r}", p.get("base_source", ""), wrap=True, h="left", size=9)
        put(ws, f"K{r}", p.get("note", ""), wrap=True, h="left", size=9)
        ws.row_dimensions[r].height = 44

    # 3. Доходный подход по сценариям
    section(ws, R_MODEL_SEC,
            "3. Доходный подход по сценариям: те же округления, что на листе «Расчет»")
    header(ws, R_MODEL_HDR, ["№", "Показатель", "Ед. изм.", "Сценарий 1",
                             "Сценарий 2", "Сценарий 3", "Активный сценарий",
                             "Формула / пояснение"])
    area_ref = input_ref(codes, "I_AREA")
    coef_ref = input_ref(codes, "I_RENTABLE_COEF")
    share_ref = input_ref(codes, "I_LAND_SHARE")
    model_rows = [
        ("Общая площадь объекта оценки", "кв. м", FMT_AREA,
         lambda c: f"={area_ref}", "Вход!F — площадь из отчета"),
        ("Коэффициент арендопригодной площади", "к-т", FMT_COEF,
         lambda c: f"={coef_ref}", "Вход!F"),
        ("Арендопригодная площадь", "кв. м", FMT_AREA,
         lambda c: f"=ROUND({c}{R_MODEL}*{c}{R_MODEL + 1},1)", "ROUND(площадь*коэф.,1)"),
        ("Ставка аренды", "руб./кв.м/мес", FMT_RUB2,
         lambda c: f"={c}{R_PARAMS['rent']}", "значение активного сценария"),
        ("Арендная ставка в год", "руб./кв.м/год", FMT_RUB2,
         lambda c: f"={c}{R_MODEL + 3}*12", "ставка*12"),
        ("Потенциальный валовый доход (ПВД)", "руб./год", FMT_RUB,
         lambda c: f"=ROUND({c}{R_MODEL + 2}*{c}{R_MODEL + 4},0)",
         "ROUND(арендопригодная площадь*годовая ставка,0)"),
        ("Коэффициент загрузки", "доля", FMT_PCT,
         lambda c: f"={c}{R_PARAMS['load']}", "значение активного сценария"),
        ("Валовый операционный доход (ВОД)", "руб./год", FMT_RUB,
         lambda c: f"=ROUND({c}{R_MODEL + 5}*{c}{R_MODEL + 6},0)", "ROUND(ПВД*загрузка,0)"),
        ("Доля операционных расходов", "доля", FMT_PCT,
         lambda c: f"={c}{R_PARAMS['opex']}", "значение активного сценария"),
        ("Операционные расходы", "руб./год", FMT_RUB,
         lambda c: f"=ROUND({c}{R_MODEL + 5}*{c}{R_MODEL + 8},0)", "ROUND(ПВД*доля расходов,0)"),
        ("Чистый операционный доход (ЧОД)", "руб./год", FMT_RUB,
         lambda c: f"={c}{R_MODEL + 7}-{c}{R_MODEL + 9}", "ВОД-расходы"),
        ("Ставка капитализации", "доля", FMT_PCT,
         lambda c: f"={c}{R_PARAMS['cap']}", "значение активного сценария"),
        ("Рыночная стоимость ЕОН", "руб.", FMT_RUB,
         lambda c: f"=ROUND({c}{R_MODEL + 10}/{c}{R_MODEL + 11},0)",
         "ROUND(ЧОД/ставка капитализации,0)"),
        ("Доля земельного участка в стоимости ЕОН", "доля", "0.00",
         lambda c: f"={share_ref}", "Вход!F"),
        ("Рыночная стоимость ОКС (доходный подход)", "руб.", FMT_RUB,
         lambda c: f"=ROUND({c}{R_MODEL + 12}*(1-{c}{R_MODEL + 13}),0)",
         "ROUND(ЕОН*(1-доля ЗУ),0)"),
    ]
    for i, (label, unit, fmt, formula, note) in enumerate(model_rows):
        r = R_MODEL + i
        put(ws, f"A{r}", i + 1, h="center")
        put(ws, f"B{r}", label, wrap=True, h="left")
        put(ws, f"C{r}", unit, h="center")
        for col in ("D", "E", "F", "G"):
            put(ws, f"{col}{r}", formula(col), h="right", fmt=fmt)
        put(ws, f"H{r}", note, wrap=True, h="left", size=9)
        ws.row_dimensions[r].height = 22

    # 4. Согласование
    section(ws, R_RECON_SEC, "4. Согласование по сценариям: веса отчета")
    header(ws, R_RECON_HDR, ["№", "Показатель", "Ед. изм.", "Сценарий 1",
                             "Сценарий 2", "Сценарий 3", "Активный сценарий",
                             "Пояснение"])
    recon_rows = [
        ("Стоимость по сравнительному подходу", "руб.", FMT_RUB,
         lambda c: f"={anchors_ref(anchors, 'comparative')}",
         "Расчет!D — сравнительный подход от сценария не зависит"),
        ("Вес сравнительного подхода", "доля", FMT_COEF,
         lambda c: f"={input_ref(codes, 'I_WEIGHT_SALE_COMP')}", "Вход!F"),
        ("Вклад сравнительного подхода", "руб.", FMT_RUB,
         lambda c: f"=ROUND({c}{R_RECON}*{c}{R_RECON + 1},0)", "ROUND(стоимость*вес,0)"),
        ("Стоимость по доходному подходу", "руб.", FMT_RUB,
         lambda c: f"={c}{R_MODEL + 14}", "строка «Рыночная стоимость ОКС (доходный подход)»"),
        ("Вес доходного подхода", "доля", FMT_COEF,
         lambda c: f"={input_ref(codes, 'I_WEIGHT_SALE_INC')}", "Вход!F"),
        ("Вклад доходного подхода", "руб.", FMT_RUB,
         lambda c: f"=ROUND({c}{R_RECON + 3}*{c}{R_RECON + 4},0)", "ROUND(стоимость*вес,0)"),
        ("Стоимость по затратному подходу", "руб.", FMT_RUB,
         lambda c: f"={anchors_ref(anchors, 'cost')}", "Расчет!D — отказ от затратного"),
        ("Вес затратного подхода", "доля", FMT_COEF,
         lambda c: f"={input_ref(codes, 'I_WEIGHT_COST')}", "Вход!F"),
        ("Вклад затратного подхода", "руб.", FMT_RUB,
         lambda c: f"=ROUND({c}{R_RECON + 6}*{c}{R_RECON + 7},0)", "ROUND(стоимость*вес,0)"),
        ("Сумма весов подходов", "доля", FMT_COEF,
         lambda c: f"=SUM({c}{R_RECON + 1},{c}{R_RECON + 4},{c}{R_RECON + 7})", "сумма весов"),
        ("Средневзвешенная стоимость", "руб.", FMT_RUB,
         lambda c: f"=SUM({c}{R_RECON + 2},{c}{R_RECON + 5},{c}{R_RECON + 8})",
         "сумма вкладов"),
        ("Шаг округления", "руб.", FMT_RUB,
         lambda c: "='Вход'!$D$9", "Вход!D9"),
        ("Итог согласования (округленно)", "руб.", FMT_RUB,
         lambda c: f"=ROUND({c}{R_RECON + 10}/{c}{R_RECON + 11},0)*{c}{R_RECON + 11}",
         "ROUND(средневзвешенная/шаг,0)*шаг"),
    ]
    for i, (label, unit, fmt, formula, note) in enumerate(recon_rows):
        r = R_RECON + i
        put(ws, f"A{r}", i + 1, h="center")
        put(ws, f"B{r}", label, wrap=True, h="left")
        put(ws, f"C{r}", unit, h="center")
        for col in ("D", "E", "F", "G"):
            put(ws, f"{col}{r}", formula(col), h="right", fmt=fmt)
        put(ws, f"H{r}", note, wrap=True, h="left", size=9)
        ws.row_dimensions[r].height = 22

    # 5. Итоги сценариев
    section(ws, R_SUM_SEC, "5. Итоги сценариев: стоимость здания по доходному подходу "
                           "и согласованная стоимость")
    header(ws, R_SUM_HDR, ["№", "Показатель", "Ед. изм.", "Сценарий 1",
                           "Сценарий 2 — базовый", "Сценарий 3", "Активный сценарий",
                           "Примечание"])
    summary_rows = [
        ("Стоимость здания по доходному подходу", "руб.", FMT_RUB,
         R_MODEL + 14, "Расчет!D: строка «Рыночная стоимость ОКС (доходный подход)»"),
        ("Согласованная стоимость (итог согласования)", "руб.", FMT_RUB,
         R_RECON + 12, "веса отчета, округление до шага из Вход!D9"),
    ]
    for i, (label, unit, fmt, src_row, note) in enumerate(summary_rows):
        r = R_SUM + i
        put(ws, f"A{r}", i + 1, h="center")
        put(ws, f"B{r}", label, wrap=True, h="left")
        put(ws, f"C{r}", unit, h="center")
        for col in ("D", "E", "F", "G"):
            put(ws, f"{col}{r}", f"={col}{src_row}", h="right", fmt=fmt,
                bold=(col == "G"))
        put(ws, f"H{r}", note, wrap=True, h="left", size=9)
        ws.row_dimensions[r].height = 30
    put(ws, f"A{R_SUM + 2}", 3, h="center")
    put(ws, f"B{R_SUM + 2}", "Отклонение доходного подхода от базового", h="left")
    put(ws, f"C{R_SUM + 2}", "руб.", h="center")
    put(ws, f"D{R_SUM + 2}", f"=D{R_SUM}-$E${R_SUM}", h="right", fmt=FMT_RUB)
    put(ws, f"E{R_SUM + 2}", f"=E{R_SUM}-$E${R_SUM}", h="right", fmt=FMT_RUB)
    put(ws, f"F{R_SUM + 2}", f"=F{R_SUM}-$E${R_SUM}", h="right", fmt=FMT_RUB)
    put(ws, f"G{R_SUM + 2}", f"=G{R_SUM}-$E${R_SUM}", h="right", fmt=FMT_RUB)
    put(ws, f"H{R_SUM + 2}", "разность к сценарию 2", wrap=True, h="left", size=9)
    put(ws, f"A{R_SUM + 3}", 4, h="center")
    put(ws, f"B{R_SUM + 3}", "Отклонение согласованной стоимости от базового", h="left")
    put(ws, f"C{R_SUM + 3}", "руб.", h="center")
    put(ws, f"D{R_SUM + 3}", f"=D{R_SUM + 1}-$E${R_SUM + 1}", h="right", fmt=FMT_RUB)
    put(ws, f"E{R_SUM + 3}", f"=E{R_SUM + 1}-$E${R_SUM + 1}", h="right", fmt=FMT_RUB)
    put(ws, f"F{R_SUM + 3}", f"=F{R_SUM + 1}-$E${R_SUM + 1}", h="right", fmt=FMT_RUB)
    put(ws, f"G{R_SUM + 3}", f"=G{R_SUM + 1}-$E${R_SUM + 1}", h="right", fmt=FMT_RUB)
    put(ws, f"H{R_SUM + 3}", "разность к сценарию 2", wrap=True, h="left", size=9)

    # 6. Сверка якорей
    section(ws, R_ANCHOR_SEC,
            "6. Сверка якорей: модель листа против расчетного файла (при сценарии 2)")
    header(ws, R_ANCHOR_HDR, ["№", "Якорь", "Модель листа «Сценарии»",
                              "Расчетный файл", "Разность", "Допуск", "Флаг",
                              "Примечание"])
    anchor_rows = [
        ("ОКС, сравнительный подход", f"=D{R_RECON}",
         anchors_ref(anchors, "comparative"), 0.5,
         "перенос без пересчета: сравнительный подход от сценария не зависит"),
        ("ОКС, доходный подход", f"=$G${R_MODEL + 14}",
         anchors_ref(anchors, "income"), 0.5,
         "модель листа пересчитывает доходный подход с теми же округлениями"),
        ("Итог согласования", f"=$G${R_RECON + 12}",
         anchors_ref(anchors, "final"), "='Вход'!$D$10",
         "допуск — половина шага округления (Вход!D10)"),
    ]
    for i, (label, model_ref, file_ref, tolerance, note) in enumerate(anchor_rows):
        r = R_ANCHORS + i
        put(ws, f"A{r}", i + 1, h="center")
        put(ws, f"B{r}", label, wrap=True, h="left")
        put(ws, f"C{r}", model_ref, h="right", fmt=FMT_RUB)
        put(ws, f"D{r}", file_ref if file_ref.startswith("=") else "=" + file_ref,
            h="right", fmt=FMT_RUB)
        put(ws, f"E{r}", f"=C{r}-D{r}", h="right", fmt=FMT_RUB)
        if isinstance(tolerance, str):
            put(ws, f"F{r}", tolerance, h="right", fmt=FMT_RUB)
        else:
            put(ws, f"F{r}", float(tolerance), h="right", fmt="0.0")
        put(ws, f"G{r}", f'=IF(ABS(E{r})<=F{r},"совпадает","расхождение")', h="center")
        put(ws, f"H{r}", note, wrap=True, h="left", size=9)
        ws.row_dimensions[r].height = 32
    ws.conditional_formatting.add(
        f"G{R_ANCHORS}:G{R_ANCHORS + 2}",
        CellIsRule(operator="equal", formula=['"расхождение"'],
                   fill=PatternFill("solid", fgColor=CLR_BAD)),
    )

    # 7. Размах влияния (служебный расчет)
    section(ws, R_SWING_SEC,
            "7. Размах влияния по стоимости здания по доходному подходу: каждый "
            "параметр отдельно, остальные — на базовых значениях")
    header(ws, R_SWING_HDR, ["№", "Параметр", "Базовое значение", "Нижняя граница",
                             "Верхняя граница", "Стоимость при нижней",
                             "Стоимость при верхней", "Размах, руб.",
                             "Источник нижней", "Таблица нижней", "Стр. нижней",
                             "Источник верхней", "Таблица верхней", "Стр. верхней",
                             "Место", "Примечание"])
    swing_meta = {
        "rent": (f"=$E${R_PARAMS['rent']}", f"=$H${R_PARAMS['rent']}",
                 f"=$I${R_PARAMS['rent']}", bounds["rent_lower"],
                 bounds["rent_upper"]),
        "load": (f"=$E${R_PARAMS['load']}", f"=$H${R_PARAMS['load']}",
                 f"=$I${R_PARAMS['load']}", bounds["load_lower"],
                 bounds["load_upper"]),
        "opex": (f"=$E${R_PARAMS['opex']}", f"=$H${R_PARAMS['opex']}",
                 f"=$I${R_PARAMS['opex']}", bounds["opex_lower"],
                 bounds["opex_upper"]),
        "cap": (f"=$E${R_PARAMS['cap']}", f"=$H${R_PARAMS['cap']}",
                f"=$I${R_PARAMS['cap']}", data["cap_shift"], data["cap_shift"]),
    }
    base_refs = {
        "rent": f"$E${R_PARAMS['rent']}",
        "load": f"$E${R_PARAMS['load']}",
        "opex": f"$E${R_PARAMS['opex']}",
        "cap": f"$E${R_PARAMS['cap']}",
    }
    swing_notes = {
        "rent": "наименьшая и наибольшая скорректированная ставка аналогов аренды",
        "load": "нижняя и верхняя границы таблицы 42",
        "opex": "нижняя и верхняя границы таблицы 43",
        "cap": "сдвиг от ставки отчета; граница в отчете не приведена",
    }
    for i, key in enumerate(["rent", "load", "opex", "cap"], start=1):
        r = R_SWING + i - 1
        base_ref, lower_ref, upper_ref, low_meta, up_meta = swing_meta[key]
        put(ws, f"A{r}", i, h="center")
        put(ws, f"B{r}", param_notes[key]["label"], wrap=True, h="left")
        put(ws, f"C{r}", base_ref, h="center",
            fmt=FMT_PCT if key != "rent" else FMT_RUB2)
        put(ws, f"D{r}", lower_ref, h="center",
            fmt=FMT_PCT if key != "rent" else FMT_RUB2)
        put(ws, f"E{r}", upper_ref, h="center",
            fmt=FMT_PCT if key != "rent" else FMT_RUB2)
        if key == "rent":
            f_low = oks_formula(rate=f"D{r}", load=base_refs["load"],
                                opex=base_refs["opex"], cap=base_refs["cap"])
            f_up = oks_formula(rate=f"E{r}", load=base_refs["load"],
                               opex=base_refs["opex"], cap=base_refs["cap"])
        elif key == "load":
            f_low = oks_formula(rate=base_refs["rent"], load=f"D{r}",
                                opex=base_refs["opex"], cap=base_refs["cap"])
            f_up = oks_formula(rate=base_refs["rent"], load=f"E{r}",
                               opex=base_refs["opex"], cap=base_refs["cap"])
        elif key == "opex":
            f_low = oks_formula(rate=base_refs["rent"], load=base_refs["load"],
                                opex=f"D{r}", cap=base_refs["cap"])
            f_up = oks_formula(rate=base_refs["rent"], load=base_refs["load"],
                               opex=f"E{r}", cap=base_refs["cap"])
        else:
            f_low = oks_formula(rate=base_refs["rent"], load=base_refs["load"],
                                opex=base_refs["opex"], cap=f"D{r}")
            f_up = oks_formula(rate=base_refs["rent"], load=base_refs["load"],
                               opex=base_refs["opex"], cap=f"E{r}")
        put(ws, f"F{r}", f_low, h="right", fmt=FMT_RUB)
        put(ws, f"G{r}", f_up, h="right", fmt=FMT_RUB)
        put(ws, f"H{r}", f"=ABS(F{r}-G{r})", h="right", fmt=FMT_RUB, bold=True)
        put(ws, f"I{r}", low_meta.get("source", ""), wrap=True, h="left", size=9)
        put(ws, f"J{r}", low_meta.get("table", "—"), h="center", size=9)
        put(ws, f"K{r}", low_meta.get("page", "—"), h="center", size=9)
        put(ws, f"L{r}", up_meta.get("source", ""), wrap=True, h="left", size=9)
        put(ws, f"M{r}", up_meta.get("table", "—"), h="center", size=9)
        put(ws, f"N{r}", up_meta.get("page", "—"), h="center", size=9)
        put(ws, f"O{r}", f'=COUNTIF($H${R_SWING}:$H${R_SWING + 3},">"&H{r})'
                         f'+COUNTIF($H${R_SWING}:H{r},H{r})', h="center", bold=True)
        put(ws, f"P{r}", swing_notes[key], wrap=True, h="left", size=9)
        ws.row_dimensions[r].height = 44

    # 8. Параметры по убыванию размаха
    section(ws, R_ORDER_SEC, "8. Параметры по убыванию размаха влияния")
    header(ws, R_ORDER_HDR, ["Место", "Параметр",
                             "Нижняя граница (в единицах параметра)",
                             "Верхняя граница (в единицах параметра)",
                             "Размах, руб.", "Источник нижней границы",
                             "Источник верхней границы", "Примечание"])
    for i in range(4):
        r = R_ORDER + i
        put(ws, f"A{r}", i + 1, h="center")
        match = f"MATCH($A{r},$O${R_SWING}:$O${R_SWING + 3},0)"
        put(ws, f"B{r}", f"=INDEX($B${R_SWING}:$B${R_SWING + 3},{match})",
            wrap=True, h="left")
        put(ws, f"C{r}", f"=INDEX($D${R_SWING}:$D${R_SWING + 3},{match})",
            h="center")
        put(ws, f"D{r}", f"=INDEX($E${R_SWING}:$E${R_SWING + 3},{match})",
            h="center")
        put(ws, f"E{r}", f"=INDEX($H${R_SWING}:$H${R_SWING + 3},{match})",
            h="right", fmt=FMT_RUB, bold=True)
        put(ws, f"F{r}",
            f'=INDEX($I${R_SWING}:$I${R_SWING + 3},{match})'
            f'&IF(INDEX($K${R_SWING}:$K${R_SWING + 3},{match})="—","",'
            f'"; "&INDEX($J${R_SWING}:$J${R_SWING + 3},{match})&", стр. "'
            f'&INDEX($K${R_SWING}:$K${R_SWING + 3},{match}))',
            wrap=True, h="left", size=9)
        put(ws, f"G{r}",
            f'=INDEX($L${R_SWING}:$L${R_SWING + 3},{match})'
            f'&IF(INDEX($N${R_SWING}:$N${R_SWING + 3},{match})="—","",'
            f'"; "&INDEX($M${R_SWING}:$M${R_SWING + 3},{match})&", стр. "'
            f'&INDEX($N${R_SWING}:$N${R_SWING + 3},{match}))',
            wrap=True, h="left", size=9)
        put(ws, f"H{r}", f"=INDEX($P${R_SWING}:$P${R_SWING + 3},{match})",
            wrap=True, h="left", size=9)
        ws.row_dimensions[r].height = 40

    # 9. Чувствительность по доходному подходу
    section(ws, R_SENS1_SEC,
            "9. Чувствительность стоимости здания по доходному подходу (руб.) "
            "к ставке капитализации и загрузке")
    put(ws, f"A{R_SENS1_HDR}", "№", bold=True, fill_color=CLR_HEADER,
        color=CLR_WHITE, h="center", size=9)
    put(ws, f"B{R_SENS1_HDR}", "Ставка капитализации ↓ / загрузка →", bold=True,
        fill_color=CLR_HEADER, color=CLR_WHITE, h="center", wrap=True, size=9)
    load_vacancy = input_literal(wb, codes, "I_VACANCY")
    load_axis = [
        (f"=$H${R_PARAMS['load']}",
         bounds_values.get("load_lower", bounds["load_lower"]["value"])),
        (f"=$E${R_PARAMS['load']}",
         (1.0 - load_vacancy) if load_vacancy is not None else None),
        (f"=$I${R_PARAMS['load']}",
         bounds_values.get("load_upper", bounds["load_upper"]["value"])),
    ]
    seen: list[float] = []
    load_cols: list[str] = []
    for ref, value in load_axis:
        if value is not None and any(abs(value - v) <= 1e-9 for v in seen):
            continue
        if value is not None:
            seen.append(value)
        load_cols.append(ref)
    for j, ref in enumerate(load_cols):
        col = get_column_letter(3 + j)
        put(ws, f"{col}{R_SENS1_HDR}", ref, bold=True, fill_color=CLR_HEADER,
            color=CLR_WHITE, h="center", fmt=FMT_PCT)
    note_col = 3 + len(load_cols)
    ws.merge_cells(start_row=R_SENS1_HDR, start_column=note_col,
                   end_row=R_SENS1_HDR, end_column=min(note_col + 2, LAST_COL))
    note_text = "остальные параметры — активный сценарий"
    if len(load_cols) < 3:
        note_text = ("граница загрузки совпала с базовым значением — столбец не "
                     "повторяется. " + note_text)
    put(ws, f"{get_column_letter(note_col)}{R_SENS1_HDR}", note_text,
        italic=True, size=9, h="left", wrap=True, border=False)
    ws.row_dimensions[R_SENS1_HDR].height = 40

    cap_vals = [f"=$D${R_BOUNDS['cap_base']}-$D${R_SHIFT}",
                f"=$D${R_BOUNDS['cap_base']}-$D${R_SHIFT}/2",
                f"=$D${R_BOUNDS['cap_base']}",
                f"=$D${R_BOUNDS['cap_base']}+$D${R_SHIFT}/2",
                f"=$D${R_BOUNDS['cap_base']}+$D${R_SHIFT}"]
    for i, cap_ref in enumerate(cap_vals):
        r = R_SENS1 + i
        put(ws, f"A{r}", i + 1, h="center")
        put(ws, f"B{r}", cap_ref, h="center", fmt=FMT_PCT, bold=(i == 2),
            fill_color=(CLR_CHECK if i == 2 else None))
        for j in range(len(load_cols)):
            col = get_column_letter(3 + j)
            put(ws, f"{col}{r}",
                oks_formula(rate=f"$G${R_PARAMS['rent']}",
                            load=f"{col}${R_SENS1_HDR}",
                            opex=f"$G${R_PARAMS['opex']}", cap=f"$B{r}"),
                h="right", fmt=FMT_RUB)
        ws.row_dimensions[r].height = 20

    # 10. Чувствительность по согласованной стоимости
    section(ws, R_SENS2_SEC,
            "10. Чувствительность согласованной стоимости (итог согласования, руб.) "
            "к ставке капитализации и загрузке")
    put(ws, f"A{R_SENS2_HDR}", "№", bold=True, fill_color=CLR_HEADER,
        color=CLR_WHITE, h="center", size=9)
    put(ws, f"B{R_SENS2_HDR}", "Ставка капитализации ↓ / загрузка →", bold=True,
        fill_color=CLR_HEADER, color=CLR_WHITE, h="center", wrap=True, size=9)
    for j, ref in enumerate(load_cols):
        col = get_column_letter(3 + j)
        put(ws, f"{col}{R_SENS2_HDR}", ref, bold=True, fill_color=CLR_HEADER,
            color=CLR_WHITE, h="center", fmt=FMT_PCT)
    ws.merge_cells(start_row=R_SENS2_HDR, start_column=note_col,
                   end_row=R_SENS2_HDR, end_column=min(note_col + 2, LAST_COL))
    put(ws, f"{get_column_letter(note_col)}{R_SENS2_HDR}",
        "веса отчета; остальные параметры — активный сценарий", italic=True,
        size=9, h="left", wrap=True, border=False)
    ws.row_dimensions[R_SENS2_HDR].height = 40
    for i in range(5):
        r = R_SENS2 + i
        src_r = R_SENS1 + i
        put(ws, f"A{r}", i + 1, h="center")
        put(ws, f"B{r}", f"=$B${src_r}", h="center", fmt=FMT_PCT, bold=(i == 2),
            fill_color=(CLR_CHECK if i == 2 else None))
        for j in range(len(load_cols)):
            col = get_column_letter(3 + j)
            formula = (
                f"=ROUND((ROUND($G${R_RECON}*$G${R_RECON + 1},0)+"
                f"ROUND({col}{src_r}*$G${R_RECON + 4},0)+"
                f"ROUND($G${R_RECON + 6}*$G${R_RECON + 7},0))"
                f"/$G${R_RECON + 11},0)*$G${R_RECON + 11}"
            )
            put(ws, f"{col}{r}", formula, h="right", fmt=FMT_RUB)
        ws.row_dimensions[r].height = 20

    # 11. Источники и пометки
    section(ws, R_NOTE_SEC, "11. Источники и пометки")
    for i, note in enumerate(data.get("notes", [])):
        r = R_NOTES + i
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=LAST_COL)
        put(ws, f"A{r}", "• " + note, wrap=True, h="left", size=9, border=False)
        ws.row_dimensions[r].height = 30

    # Настройки листа
    ws.freeze_panes = "A9"
    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.print_title_rows = "1:3"

    dv = DataValidation(
        type="whole", operator="between", formula1="1", formula2="3",
        allow_blank=False, showErrorMessage=True, errorTitle="Номер сценария",
        error="Введите 1 (неблагоприятный), 2 (базовый) или 3 (благоприятный).",
    )
    ws.add_data_validation(dv)
    dv.add(f"D{R_SEL}")


def anchors_ref(anchors: dict[str, int], key: str) -> str:
    return f"'Расчет'!$D${anchors[key]}"


# ---------------------------------------------------------------------------
# Команда build
# ---------------------------------------------------------------------------


def build(file_path: Path, data_path: Path, out_path: Path | None = None,
          selector: int | None = None, preserve: bool = True) -> None:
    data = load_data(data_path)
    path = Path(file_path)
    if not path.exists():
        fail(f"нет расчетного файла: {path}")
    wb = load_workbook(path)
    for name in ("Вход", "Аренда", "Расчет"):
        if name not in wb.sheetnames:
            fail(f"в книге нет листа «{name}»: это не расчетный файл навыка raschetnyj-fajl")

    codes = locate_inputs(wb)
    anchors = locate_anchors(wb)
    rent_row = locate_rent_adjusted_row(wb)

    old_inputs: dict[str, float] = {}
    if SHEET in wb.sheetnames:
        old = wb[SHEET]
        if preserve:
            for ref in ("D6", "D7", "D12", "D13", "D14", "D15"):
                value = old[ref].value
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    old_inputs[ref] = float(value)
        wb.remove(old)

    sel = selector if selector is not None else old_inputs.get("D6",
                                                              data["controls"]["selector"])
    if sel is None:
        sel = data["controls"]["selector"]
    sel = int(round(float(sel)))
    if sel not in (1, 2, 3):
        fail(f"номер сценария должен быть 1, 2 или 3, а не {sel}")

    shift = old_inputs.get("D7", data["controls"]["cap_shift"])
    if not isinstance(shift, (int, float)) or isinstance(shift, bool) or shift <= 0:
        fail("сдвиг ставки капитализации (D7) должен быть положительным числом")
    shift = float(shift)

    bounds = {b["key"]: b for b in data["bounds"]}
    bounds_values: dict[str, float] = {}
    for key in ("load_lower", "load_upper", "opex_lower", "opex_upper"):
        if key not in bounds:
            fail(f"в данных нет границы {key}")
        base = bounds[key].get("value")
        if not isinstance(base, (int, float)):
            fail(f"у границы {key} нет числового значения")
        old_ref = f"D{R_BOUNDS[key]}"
        value = old_inputs.get(old_ref, float(base))
        if not isinstance(value, (int, float)) or not (0 < float(value) < 1):
            fail(f"граница {key} должна быть долей от 0 до 1")
        bounds_values[key] = float(value)

    build_sheet(
        wb, data,
        selector=sel,
        shift=shift,
        bounds_values=bounds_values,
        anchors=anchors,
        codes=codes,
        rent_row=rent_row,
    )
    out = Path(out_path) if out_path else path
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    print(f"лист «{SHEET}» записан: {out}")
    print(f"  D6 — номер сценария ({sel}); D7 — сдвиг ставки капитализации "
          f"({shift:.4g})")
    print(f"  границы: D{R_BOUNDS['load_lower']}–D{R_BOUNDS['opex_upper']} — числа "
          f"отчета, D{R_BOUNDS['rent_lower']}–D{R_BOUNDS['rent_upper']} — MIN/MAX "
          f"аренды, D{R_BOUNDS['cap_base']} — ставка капитализации")
    print(f"  модель: строки {R_MODEL}–{R_MODEL + 14}; согласование: "
          f"{R_RECON}–{R_RECON + 12}; итоги: {R_SUM}–{R_SUM + 3}")
    print(f"  якоря: {R_ANCHORS}–{R_ANCHORS + 2}; размах: {R_SWING}–{R_SWING + 3}; "
          f"порядок: {R_ORDER}–{R_ORDER + 3}")
    print(f"  чувствительность: {R_SENS1}–{R_SENS1 + 4} и {R_SENS2}–{R_SENS2 + 4}")
    print("  исходные листы не изменены; далее: recalc, затем check")


# ---------------------------------------------------------------------------
# Команда backup
# ---------------------------------------------------------------------------


def backup(file_path: Path, date_str: str | None = None,
           out_dir: Path | None = None) -> Path:
    src = Path(file_path)
    if not src.exists():
        fail(f"нет расчетного файла: {src}")
    date = date_str or dt.date.today().isoformat()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
        fail("дата копии должна быть в виде ГГГГ-ММ-ДД")
    folder = Path(out_dir) if out_dir else src.parent
    folder.mkdir(parents=True, exist_ok=True)
    dst = folder / f"{src.stem}_{date}{src.suffix}"
    n = 2
    while dst.exists():
        dst = folder / f"{src.stem}_{date}_{n}{src.suffix}"
        n += 1
    shutil.copy2(src, dst)
    print(f"копия расчетного файла: {dst}")
    return dst


# ---------------------------------------------------------------------------
# Пересчет LibreOffice
# ---------------------------------------------------------------------------


def find_soffice() -> str | None:
    for name in ("soffice", "libreoffice"):
        found = shutil.which(name)
        if found:
            return found
    for candidate in ("/Applications/LibreOffice.app/Contents/MacOS/soffice",
                      "/usr/bin/libreoffice", "/usr/bin/soffice"):
        if Path(candidate).exists():
            return candidate
    return None


def write_lo_profile(profile: Path) -> None:
    user = profile / "user"
    user.mkdir(parents=True, exist_ok=True)
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop></item>
 <item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="ODFRecalcMode" oor:op="fuse"><value>0</value></prop></item>
</oor:items>
"""
    (user / "registrymodifications.xcu").write_text(xml, encoding="utf-8")


def recalc_book(path: Path, timeout: int = 240) -> None:
    soffice = find_soffice()
    if not soffice:
        fail("LibreOffice не найден: нужен soffice в PATH или в /Applications.")
    path = path.resolve()
    if not path.exists():
        fail(f"файл не найден: {path}")
    with tempfile.TemporaryDirectory(prefix="scenarii_lo_") as td:
        td = Path(td)
        profile = td / "profile"
        write_lo_profile(profile)
        outdir = td / "out"
        outdir.mkdir()
        cmd = [soffice, f"-env:UserInstallation={profile.resolve().as_uri()}",
               "--headless", "--convert-to", "xlsx:Calc Office Open XML",
               "--outdir", str(outdir), str(path)]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if proc.returncode != 0:
            fail(f"LibreOffice вернул {proc.returncode}:\n{proc.stdout}\n{proc.stderr}")
        produced = outdir / path.name
        if not produced.exists():
            candidates = list(outdir.glob("*.xlsx"))
            if not candidates:
                fail(f"LibreOffice не создал файл:\n{proc.stdout}\n{proc.stderr}")
            produced = candidates[0]
        shutil.copy2(produced, path)
    print(f"пересчитано: {path}")


# ---------------------------------------------------------------------------
# Проверка листа
# ---------------------------------------------------------------------------

REF_RE = re.compile(
    r"(?:(?P<sheet>'[^']+'|[A-Za-zА-Яа-яЁё0-9_ ]+)!)?"
    r"(?P<start>\$?[A-Z]{1,3}\$?\d+)"
    r"(?::(?P<end>\$?[A-Z]{1,3}\$?\d+))?"
)


def coord_tuple(coord: str) -> tuple[int, int]:
    coord = coord.replace("$", "")
    m = re.fullmatch(r"([A-Z]{1,3})(\d+)", coord)
    if not m:
        raise ValueError(coord)
    col = 0
    for ch in m.group(1):
        col = col * 26 + (ord(ch) - ord("A") + 1)
    return int(m.group(2)), col


def expand_range(start: str, end: str | None) -> Iterable[str]:
    r1, c1 = coord_tuple(start)
    if not end:
        yield f"{get_column_letter(c1)}{r1}"
        return
    r2, c2 = coord_tuple(end)
    if abs(r2 - r1) * abs(c2 - c1) > 2000:
        return
    for rr in range(min(r1, r2), max(r1, r2) + 1):
        for cc in range(min(c1, c2), max(c1, c2) + 1):
            yield f"{get_column_letter(cc)}{rr}"


def formula_refs(formula: str, current_sheet: str) -> Iterable[tuple[str, str]]:
    s = re.sub(r'"(?:[^"]|"")*"', '""', formula)
    for m in REF_RE.finditer(s):
        sheet = m.group("sheet")
        sheet = sheet.strip("'") if sheet else current_sheet
        for coord in expand_range(m.group("start"), m.group("end")):
            yield sheet, coord


def check(file_path: Path, data_path: Path) -> int:
    data = load_data(data_path)
    path = Path(file_path)
    if not path.exists():
        fail(f"нет расчетного файла: {path}")
    wbf = load_workbook(path, data_only=False)
    wbv = load_workbook(path, data_only=True)
    if SHEET not in wbf.sheetnames:
        print(f"листа «{SHEET}» нет: выполните build")
        return 1
    ws = wbf[SHEET]
    wv = wbv[SHEET]
    issues: list[str] = []

    # 1. Номер сценария
    sel_row = find_label_row(ws, "Номер активного сценария")
    if not sel_row:
        print("не найдена строка «Номер активного сценария»")
        return 1
    sel = wv.cell(row=sel_row, column=4).value
    print("== Сценарий ==")
    print(f"D{sel_row} = {sel!r}")
    if sel not in (1, 2, 3):
        issues.append(f"номер сценария D{sel_row} = {sel!r}, должен быть 1, 2 или 3")

    # 2. Формулы и числа
    print("\n== Расчетные ячейки: формула или число ==")
    allowed = set(ALLOWED_NUMERIC)
    for prefix in ("Загрузка: нижняя граница", "Загрузка: верхняя граница",
                   "Операционные расходы: нижняя граница",
                   "Операционные расходы: верхняя граница"):
        r = find_label_row(ws, prefix)
        if r:
            allowed.add(f"D{r}")
    for label in ("ОКС, сравнительный подход", "ОКС, доходный подход"):
        r = find_label_row(ws, label)
        if r:
            allowed.add(f"F{r}")
    numbers = []
    for row in ws.iter_rows():
        for c in row:
            value = c.value
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                continue
            if c.column_letter == "A" or c.coordinate in allowed:
                continue
            numbers.append(c.coordinate)
    if numbers:
        print(f"найдены числа в расчетных ячейках: {len(numbers)}")
        for coord in numbers[:20]:
            print(f"  ! {coord} = {ws[coord].value}")
        issues.extend(f"число в расчетной ячейке {coord}" for coord in numbers)
    else:
        print("чисел в расчетных ячейках нет: все расчетные ячейки — формулы")

    # 3. Сверка якорей
    print("\n== Сверка якорей ==")
    anchor_labels = [("ОКС, сравнительный подход", "сравнительный подход"),
                     ("ОКС, доходный подход", "доходный подход"),
                     ("Итог согласования", "итог согласования")]
    for label, human in anchor_labels:
        r = find_exact_row(ws, label)
        if not r:
            print(f"  ! не найдена строка «{label}»")
            issues.append(f"нет строки «{label}»")
            continue
        model = wv[f"C{r}"].value
        file_value = wv[f"D{r}"].value
        diff = wv[f"E{r}"].value
        tol = wv[f"F{r}"].value
        if None in (model, file_value, diff, tol):
            print(f"  {human}: значения не вычислены — выполните recalc")
            issues.append(f"{human}: книга не пересчитана")
            continue
        ok = abs(float(diff)) <= float(tol) + 1e-9
        print(f"  {human}: модель {float(model):,.0f} | файл {float(file_value):,.0f} | "
              f"разность {float(diff):,.0f} | допуск {float(tol):g} — "
              f"{'совпадает' if ok else 'РАСХОЖДЕНИЕ'}")
        if not ok and sel == 2:
            issues.append(f"{human}: разность {diff} больше допуска {tol}")
        if not ok and sel != 2:
            print("    (сценарий не базовый: разность ожидаема)")

    # 4. Сортировка размаха
    print("\n== Размах влияния ==")
    order_rows = [R_ORDER + i for i in range(4)]
    swings = [wv[f"E{r}"].value for r in order_rows]
    if any(v is None for v in swings):
        print("  значения размаха не вычислены — выполните recalc")
        issues.append("размах: книга не пересчитана")
    else:
        values = [float(v) for v in swings]
        print("  размах по убыванию: " + ", ".join(f"{v:,.0f}" for v in values))
        for a, b in zip(values, values[1:]):
            if a + 1e-6 < b:
                issues.append("порядок размаха не по убыванию")
                break

    # 5. Оси чувствительности
    print("\n== Оси таблиц чувствительности ==")
    loads = [wv.cell(row=R_SENS1_HDR, column=3 + j).value for j in range(3)]
    loads = [float(v) for v in loads if isinstance(v, (int, float))]
    print(f"  загрузка: {', '.join(f'{v:.2%}' for v in loads)}")
    if len(loads) < 2:
        issues.append("в таблице чувствительности меньше двух столбцов загрузки")
    if len(set(round(v, 9) for v in loads)) != len(loads):
        issues.append("столбцы загрузки повторяются")
    caps = [wv[f"B{R_SENS1 + i}"].value for i in range(5)]
    caps = [float(v) for v in caps if isinstance(v, (int, float))]
    print(f"  ставка капитализации: {', '.join(f'{v:.2%}' for v in caps)}")
    if len(set(round(v, 9) for v in caps)) != len(caps):
        issues.append("строки ставки капитализации повторяются")

    # 6. Источники у границ
    print("\n== Границы и источники ==")
    for key, r in R_BOUNDS.items():
        source = text(ws[f"E{r}"].value)
        table = text(ws[f"F{r}"].value)
        page = text(ws[f"G{r}"].value)
        if not source or not table or not page:
            issues.append(f"у границы {key} не заполнены источник, таблица или страница")
        print(f"  {text(ws[f'B{r}'].value)}: значение "
              f"{wv[f'D{r}'].value!r}, {table}, стр. {page}")
    cap_note = "граница в отчете не приведена" in text(ws[f"P{R_SWING + 3}"].value)
    print(f"  пометка у ставки капитализации: "
          f"{'есть' if cap_note else 'НЕТ'}")
    if not cap_note:
        issues.append("у ставки капитализации нет пометки «граница в отчете не приведена»")

    # 7. Ссылки на пустые ячейки
    print("\n== Ссылки на пустые ячейки ==")
    empty: list[str] = []
    for row in ws.iter_rows():
        for c in row:
            value = c.value
            if not (isinstance(value, str) and value.startswith("=")):
                continue
            for sheet_name, coord in formula_refs(value, ws.title):
                if sheet_name not in wbf.sheetnames:
                    continue
                target = wbf[sheet_name][coord]
                if target.value is None:
                    empty.append(f"{c.coordinate} → {sheet_name}!{coord}")
    if empty:
        print(f"  найдено ссылок на пустые ячейки: {len(empty)}")
        for item in empty[:20]:
            print(f"  ! {item}")
        issues.extend(f"ссылка на пустую ячейку {item}" for item in empty)
    else:
        print("  ссылок на пустые ячейки нет")

    print("\n== Итог ==")
    if issues:
        for issue in issues:
            print(f"  ! {issue}")
        print(f"ЗАМЕЧАНИЙ: {len(issues)}")
        return 1
    print("ПРОВЕРКА ПРОЙДЕНА")
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Сценарный расчет по готовому расчетному файлу: лист «Сценарии».",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_build = sub.add_parser("build", help="записать лист «Сценарии» формулами")
    p_build.add_argument("--file", default=str(DEFAULT_FILE), help="расчетный файл")
    p_build.add_argument("--data", default=str(DEFAULT_DATA), help="файл данных")
    p_build.add_argument("--out", default=None, help="куда записать книгу")
    p_build.add_argument("--selector", type=int, default=None,
                         help="номер активного сценария 1/2/3")
    p_build.add_argument("--reset", action="store_true",
                         help="не сохранять прежние значения желтых ячеек")

    p_backup = sub.add_parser("backup", help="копия расчетного файла с датой в имени")
    p_backup.add_argument("--file", default=str(DEFAULT_FILE))
    p_backup.add_argument("--date", default=None, help="ГГГГ-ММ-ДД")
    p_backup.add_argument("--out-dir", default=None)

    p_recalc = sub.add_parser("recalc", help="пересчитать книгу в LibreOffice")
    p_recalc.add_argument("--file", default=str(DEFAULT_FILE))
    p_recalc.add_argument("--timeout", type=int, default=240)

    p_check = sub.add_parser("check", help="проверить лист «Сценарии»")
    p_check.add_argument("--file", default=str(DEFAULT_FILE))
    p_check.add_argument("--data", default=str(DEFAULT_DATA))

    args = parser.parse_args(argv)
    if args.command == "build":
        build(Path(args.file), Path(args.data),
              Path(args.out) if args.out else None,
              selector=args.selector, preserve=not args.reset)
        return 0
    if args.command == "backup":
        backup(Path(args.file), args.date,
               Path(args.out_dir) if args.out_dir else None)
        return 0
    if args.command == "recalc":
        recalc_book(Path(args.file), timeout=args.timeout)
        return 0
    if args.command == "check":
        return check(Path(args.file), Path(args.data))
    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
