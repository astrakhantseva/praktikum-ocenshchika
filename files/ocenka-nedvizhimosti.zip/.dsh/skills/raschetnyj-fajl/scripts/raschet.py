#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Расчетный файл по отчету об оценке недвижимости.

Команды:
  extract  — собрать и проверить реестр исходных чисел по тексту отчета;
  build    — записать книгу Excel формулами по модели;
  recalc   — пересчитать книгу в LibreOffice;
  check    — проверить веса, пустые ссылки, числа вместо формул,
             ссылки расчетных ячеек на числа отчета и флаги расхождений.

Пути по умолчанию:
  модель   — .dsh/skills/raschetnyj-fajl/data/model.json
  отчет    — Склад/Результаты/Отчет_текст.md
  книга    — Склад/Результаты/Расчетный файл по складу.xlsx
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from copy import copy
from pathlib import Path
from typing import Any, Iterable

from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter, range_boundaries
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.properties import PageSetupProperties

SKILL_DIR = Path(__file__).resolve().parent.parent
DEFAULT_MODEL = SKILL_DIR / "data" / "model.json"
DEFAULT_OUT = Path("Склад/Результаты/Расчетный файл по складу.xlsx")
DEFAULT_REPORT = Path("Склад/Результаты/Отчет_текст.md")

# ---------------------------------------------------------------------------
# Общие помощники
# ---------------------------------------------------------------------------

FONT = "Calibri"
CLR_HEADER = "1F4E79"
CLR_SECTION = "D9E2F3"
CLR_INPUT = "FFF2CC"
CLR_REPORT = "E7E6E6"
CLR_CHECK = "E2EFDA"
CLR_BAD = "F8CBAD"
CLR_WHITE = "FFFFFF"

THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def norm_variants(text: str) -> list[str]:
    """Варианты нормализации текста: переносы, дефисы, пробелы."""
    if text is None:
        return [""]
    s = str(text).replace("\u00a0", " ").replace("ё", "е").replace("Ё", "Е")
    s = s.replace("–", "-").replace("—", "-").replace("−", "-")
    a = re.sub(r"-\s*\n\s*", "", s)
    b = re.sub(r"-\s*\n\s*", "-", s)
    c = s
    out = []
    for x in (a, b, c):
        x = re.sub(r"\s+", " ", x).strip()
        out.append(x)
    return out


def norm(text: str) -> str:
    return norm_variants(text)[0]


def split_pages(report_text: str) -> dict[int, str]:
    parts = re.split(r"\[СТРАНИЦА\s+(\d+)\]", report_text)
    pages: dict[int, str] = {}
    for i in range(1, len(parts), 2):
        pages[int(parts[i])] = parts[i + 1]
    return pages


def parse_number(token: str) -> float | None:
    t = token.strip().replace("\u00a0", " ").replace(" ", "")
    percent = t.endswith("%")
    t = t.rstrip("%").replace(",", ".")
    t = re.sub(r"[^0-9.+-]", "", t)
    if not t or t in {"+", "-", ".", "-.", "+."}:
        return None
    try:
        v = float(t)
    except ValueError:
        return None
    if percent:
        v /= 100.0
    return v


NUMBER_TOKEN = re.compile(r"[-+]?\d[\d\s\u00a0]*(?:[.,]\d+)?\s*%?")


def extract_closest_number(text: str, target: float) -> tuple[float | None, str | None]:
    best = None
    best_token = None
    best_diff = float("inf")
    for m in NUMBER_TOKEN.finditer(text or ""):
        token = m.group(0)
        v = parse_number(token)
        if v is None:
            continue
        d = abs(v - target)
        if d < best_diff:
            best_diff = d
            best = v
            best_token = token
    return best, best_token


def resolve(value: Any, registry: "InputRegistry") -> Any:
    """Подставить {{ID}} в ссылки на лист «Вход»."""
    if not isinstance(value, str):
        return value
    def repl(m: re.Match) -> str:
        key = m.group(1)
        if key == "ACTIVE_RATE":
            return "'Вход'!$D$8"
        if key == "STEP":
            return "'Вход'!$D$9"
        if key == "MANUAL_RATE":
            return "'Вход'!$D$6"
        row = registry.rows.get(key)
        if row is None:
            raise KeyError(f"Неизвестный вход: {key}")
        return f"'Вход'!$F${row}"
    return re.sub(r"\{\{([A-Z0-9_]+)\}\}", repl, value)


def formula_or_number(value: Any, registry: "InputRegistry") -> str | int | float:
    """В расчетной ячейке число записывается формулой =число."""
    v = resolve(value, registry)
    if isinstance(v, str):
        if v.startswith("="):
            return v
        if re.fullmatch(r"[-+]?\d+(?:[.,]\d+)?", v.strip()):
            return "=" + v.strip().replace(",", ".")
        return "=" + v
    if isinstance(v, bool):
        return "=" + ("1" if v else "0")
    if isinstance(v, (int, float)):
        return "=" + repr(float(v)) if isinstance(v, float) else "=" + str(v)
    return "=" + str(v)


# ---------------------------------------------------------------------------
# Стили
# ---------------------------------------------------------------------------

def style_header(ws, row: int, first_col: int, last_col: int) -> None:
    for c in range(first_col, last_col + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name=FONT, bold=True, color=CLR_WHITE, size=10)
        cell.fill = PatternFill("solid", fgColor=CLR_HEADER)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[row].height = 42


def style_section(ws, row: int, first_col: int, last_col: int, title: str) -> None:
    ws.merge_cells(start_row=row, start_column=first_col, end_row=row, end_column=last_col)
    cell = ws.cell(row=row, column=first_col, value=title)
    cell.font = Font(name=FONT, bold=True, size=10, color=CLR_HEADER)
    cell.fill = PatternFill("solid", fgColor=CLR_SECTION)
    cell.alignment = Alignment(horizontal="left", vertical="center")
    for c in range(first_col, last_col + 1):
        ws.cell(row=row, column=c).border = BORDER
    ws.row_dimensions[row].height = 22


def style_row(ws, row: int, first_col: int, last_col: int, fill: str | None = None,
              bold: bool = False, wrap: bool = False) -> None:
    for c in range(first_col, last_col + 1):
        cell = ws.cell(row=row, column=c)
        cell.border = BORDER
        cell.font = Font(name=FONT, size=10, bold=bold)
        cell.alignment = Alignment(vertical="top", wrap_text=wrap)
        if fill:
            cell.fill = PatternFill("solid", fgColor=fill)


def setup_print(ws, last_row: int, last_col: int, title_rows: str | None = None) -> None:
    """Печать: альбомная A4, вписать по ширине, повторять шапку."""
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = 0.25
    ws.page_margins.right = 0.25
    ws.page_margins.top = 0.4
    ws.page_margins.bottom = 0.4
    ws.print_area = f"A1:{get_column_letter(last_col)}{last_row}"
    if title_rows:
        ws.print_title_rows = title_rows
    ws.sheet_view.zoomScale = 85


def set_widths(ws, widths: dict[str, int]) -> None:
    for col, w in widths.items():
        ws.column_dimensions[col].width = w


# ---------------------------------------------------------------------------
# Реестр входов
# ---------------------------------------------------------------------------

class InputRegistry:
    def __init__(self, model: dict):
        self.model = model
        self.rows: dict[str, int] = {}
        self.meta_rows: list[dict] = []
        self.ws = None

    def write(self, wb: Workbook) -> None:
        ws = wb.active
        ws.title = "Вход"
        self.ws = ws
        ws.sheet_view.showGridLines = False
        set_widths(ws, {"A": 5, "B": 18, "C": 20, "D": 46, "E": 12, "F": 15, "G": 15,
                        "H": 11, "I": 9, "J": 9, "K": 14, "L": 70, "M": 7, "N": 18, "O": 9, "P": 40})

        ws.merge_cells("A1:P1")
        c = ws["A1"]
        c.value = "ВХОД — исходные числа отчета об оценке"
        c.font = Font(name=FONT, bold=True, size=14, color=CLR_HEADER)
        c.alignment = Alignment(horizontal="left", vertical="center")
        ws.row_dimensions[1].height = 26
        ws.merge_cells("A2:P2")
        c = ws["A2"]
        c.value = ("Каждое исходное число внесено один раз; столбец «Число из отчета» — только для сверки. "
                   "Желтые ячейки правятся, серые — нет.")
        c.font = Font(name=FONT, italic=True, size=9, color="404040")
        c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        ws.row_dimensions[2].height = 28

        # Параметры правки
        style_section(ws, 4, 1, 16, "Параметры правки и переключатели")
        controls = self.model.get("controls", {})
        rows = [
            (5, "switch", "Переключатель ставки аренды", controls.get("switch", {}).get("value", "расчетная"),
             controls.get("switch", {}).get("quote", ""), controls.get("switch", {}).get("page", ""), "23",
             "расчетная — по листу «Аренда»; ручная — ячейка D6"),
            (6, "manual_rate", "Ручная ставка аренды, руб./кв.м/мес", controls.get("manual_rate", {}).get("value", 250),
             controls.get("manual_rate", {}).get("quote", ""), controls.get("manual_rate", {}).get("page", ""), "23",
             "правится вручную"),
            (7, "calc_rate", "Расчетная ставка по аналогам аренды, руб./кв.м/мес", None,
             "Расчет по листу «Аренда»", "", "23", "формула, не правится"),
            (8, "active_rate", "Действующая ставка аренды, руб./кв.м/мес", None,
             "Используется в доходном подходе", "", "23", "формула выбора"),
            (9, "step", "Шаг округления итога, руб.", controls.get("step", {}).get("value", 100000),
             controls.get("step", {}).get("quote", ""), controls.get("step", {}).get("page", ""), "28",
             "итог округляется до этого шага"),
            (10, "tol", "Допуск итога, руб.", None, "Половина последнего напечатанного разряда", "", "28",
             "формула, не правится"),
        ]
        for r, key, label, value, quote, page, clause, note in rows:
            ws.cell(row=r, column=1, value=label).font = Font(name=FONT, bold=True, size=10)
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
            ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=9)
            ws.merge_cells(start_row=r, start_column=12, end_row=r, end_column=16)
            ws.cell(row=r, column=1).alignment = Alignment(vertical="center", wrap_text=True)
            ws.cell(row=r, column=4, value=value)
            ws.cell(row=r, column=5, value=quote).alignment = Alignment(vertical="center", wrap_text=True)
            ws.cell(row=r, column=10, value=page)
            ws.cell(row=r, column=11, value=clause)
            ws.cell(row=r, column=12, value=note).alignment = Alignment(vertical="center", wrap_text=True)
            style_row(ws, r, 1, 16, fill=None, wrap=True)
            ws.row_dimensions[r].height = 30

        # формулы переключателя
        ws["D7"] = "=Аренда!E_RESULT"
        ws["D8"] = '=IF(D5="расчетная",D7,D6)'
        ws["D10"] = "=D9/2"
        ws["D5"].fill = PatternFill("solid", fgColor="DDEBF7")
        ws["D6"].fill = PatternFill("solid", fgColor=CLR_INPUT)
        ws["D9"].fill = PatternFill("solid", fgColor=CLR_INPUT)
        ws["D7"].fill = PatternFill("solid", fgColor=CLR_REPORT)
        ws["D8"].fill = PatternFill("solid", fgColor=CLR_REPORT)
        ws["D10"].fill = PatternFill("solid", fgColor=CLR_REPORT)
        for coord in ("D5", "D6", "D9"):
            ws[coord].font = Font(name=FONT, bold=True, size=11)
            ws[coord].alignment = Alignment(horizontal="center", vertical="center")
        for coord in ("D7", "D8", "D10"):
            ws[coord].font = Font(name=FONT, size=11)
            ws[coord].alignment = Alignment(horizontal="center", vertical="center")
        ws["D9"].number_format = "#,##0"
        ws["D10"].number_format = "#,##0"
        ws["D7"].number_format = "#,##0.00"
        ws["D8"].number_format = "#,##0.00"

        dv = DataValidation(type="list", formula1='"расчетная,ручная"', allow_blank=False)
        dv.error = "Выберите «расчетная» или «ручная»"
        dv.errorTitle = "Ставка аренды"
        ws.add_data_validation(dv)
        dv.add(ws["D5"])

        # Шапка таблицы входов
        header_row = 12
        headers = ["№", "Код", "Блок", "Показатель", "Ед. изм.", "Значение (вход)",
                   "Число из отчета", "Разница", "Последний разряд", "Допуск", "Флаг",
                   "Цитата", "Стр.", "Таблица", "Пункт ФСО 7", "Примечание"]
        for i, h in enumerate(headers, start=1):
            ws.cell(row=header_row, column=i, value=h)
        style_header(ws, header_row, 1, len(headers))

        # Секции и строки
        r = header_row + 1
        n = 0
        current_section = None
        for item in self.model["inputs"]:
            sec = item.get("section", "")
            if sec != current_section:
                style_section(ws, r, 1, 16, sec)
                r += 1
                current_section = sec
            n += 1
            self.rows[item["id"]] = r
            ws.cell(row=r, column=1, value=n)
            ws.cell(row=r, column=2, value=item["id"])
            ws.cell(row=r, column=3, value=sec)
            ws.cell(row=r, column=4, value=item["label"])
            ws.cell(row=r, column=5, value=item.get("unit", ""))
            if item.get("formula"):
                ws.cell(row=r, column=6, value=item["formula"])
            else:
                ws.cell(row=r, column=6, value=item["value"])
            ws.cell(row=r, column=7, value=item.get("report_value", item["value"]))
            ws.cell(row=r, column=8, value=f"=F{r}-G{r}")
            ws.cell(row=r, column=9, value=item.get("precision"))
            ws.cell(row=r, column=10, value=f"=I{r}/2")
            ws.cell(row=r, column=11, value=f'=IF(ABS(H{r})<=J{r},"совпадает","расхождение")')
            ws.cell(row=r, column=12, value=item.get("quote", ""))
            ws.cell(row=r, column=13, value=item.get("page", ""))
            ws.cell(row=r, column=14, value=item.get("table", ""))
            ws.cell(row=r, column=15, value=item.get("clause", ""))
            ws.cell(row=r, column=16, value=item.get("note", ""))
            style_row(ws, r, 1, 16, wrap=True)
            ws.cell(row=r, column=6).fill = PatternFill(
                "solid", fgColor=CLR_REPORT if item.get("registry_ref") else CLR_INPUT)
            ws.cell(row=r, column=6).font = Font(name=FONT, size=10, bold=True)
            ws.cell(row=r, column=7).fill = PatternFill("solid", fgColor=CLR_REPORT)
            ws.cell(row=r, column=8).number_format = "0.########"
            ws.cell(row=r, column=9).number_format = "0.########"
            ws.cell(row=r, column=10).number_format = "0.########"
            ws.cell(row=r, column=6).number_format = "0.########"
            ws.cell(row=r, column=7).number_format = "0.########"
            ws.row_dimensions[r].height = 34
            self.meta_rows.append({
                "row": r, "quote": item.get("quote", ""), "page": item.get("page", ""),
                "clause": item.get("clause", ""), "id": item["id"],
            })
            r += 1
        last = r - 1
        ws.freeze_panes = f"A{header_row + 1}"
        ws.auto_filter.ref = f"A{header_row}:P{last}"
        ws.conditional_formatting.add(f"K{header_row + 1}:K{last}",
                                      CellIsRule(operator="equal", formula=['"расхождение"'],
                                                 fill=PatternFill("solid", fgColor=CLR_BAD)))
        self.last_row = last
        self.header_row = header_row


# ---------------------------------------------------------------------------
# Лист «Продажа» / «Аренда»
# ---------------------------------------------------------------------------

def _write_value(ws, row: int, col: int, value: Any, registry: InputRegistry) -> None:
    v = resolve(value, registry)
    if isinstance(v, str):
        if v.startswith("="):
            ws.cell(row=row, column=col, value=v)
        elif re.fullmatch(r"[-+]?\d+(?:[.,]\d+)?", v.strip()):
            ws.cell(row=row, column=col, value=float(v.strip().replace(",", ".")))
        elif re.fullmatch(r"'(?:[^']+)'!\$?[A-Z]{1,3}\$?\d+", v) or \
             re.fullmatch(r"[A-Za-zА-Яа-яЁё0-9_]+!\$?[A-Z]{1,3}\$?\d+", v):
            ws.cell(row=row, column=col, value="=" + v)
        else:
            ws.cell(row=row, column=col, value=v)
    else:
        ws.cell(row=row, column=col, value=v)


def build_analog_sheet(wb: Workbook, model: dict, registry: InputRegistry,
                       kind: str) -> dict:
    """kind = sale | rent."""
    data = model[kind]
    title = "ПРОДАЖА — сравнительный подход" if kind == "sale" else "АРЕНДА — доходный подход"
    ws = wb.create_sheet(data["sheet"])
    ws.sheet_view.showGridLines = False
    set_widths(ws, {"A": 5, "B": 48, "C": 10, "D": 17, "E": 14, "F": 14, "G": 14,
                    "H": 40, "I": 13, "J": 18, "K": 10, "L": 10})
    ws.merge_cells("A1:L1")
    c = ws["A1"]
    c.value = title
    c.font = Font(name=FONT, bold=True, size=14, color=CLR_HEADER)
    c.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 26
    ws.merge_cells("A2:L2")
    c = ws["A2"]
    c.value = ("Аналоги, все корректировки с таблицей и страницей справочника и таблицей и страницей отчета; "
               "скорректированные цены, веса и коэффициент вариации — формулами.")
    c.font = Font(name=FONT, italic=True, size=9, color="404040")
    c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    ws.row_dimensions[2].height = 28

    header_row = 4
    headers = ["№", "Элемент сравнения", "Ед. изм.", "Оцениваемый объект",
               "Аналог 1", "Аналог 2", "Аналог 3",
               "Таблица справочника", "Стр. справочника", "Таблица отчета",
               "Стр. отчета", "Пункт ФСО 7"]
    for i, h in enumerate(headers, start=1):
        ws.cell(row=header_row, column=i, value=h)
    style_header(ws, header_row, 1, 12)

    r = header_row + 1
    num = 0

    def row(label: str, unit: str, values: list[Any], ref_table: str = "", ref_page: str = "",
            report_table: str = "", report_page: Any = "", clause: str = "22",
            fill: str | None = None, bold: bool = False) -> int:
        nonlocal r, num
        num += 1
        ws.cell(row=r, column=1, value=num)
        ws.cell(row=r, column=2, value=label)
        ws.cell(row=r, column=3, value=unit)
        for j, v in enumerate(values):
            _write_value(ws, r, 4 + j, v, registry)
        ws.cell(row=r, column=8, value=ref_table)
        ws.cell(row=r, column=9, value=ref_page)
        ws.cell(row=r, column=10, value=report_table)
        ws.cell(row=r, column=11, value=report_page)
        ws.cell(row=r, column=12, value=clause)
        style_row(ws, r, 1, 12, fill=fill, bold=bold, wrap=True)
        long_meta = len(str(ref_table)) > 32 or len(str(report_table)) > 18
        ws.row_dimensions[r].height = 48 if label in ("Источник информации", "Адрес объекта") else (36 if long_meta else 26)
        r += 1
        return r - 1

    # Исходные данные
    style_section(ws, r, 1, 12, "1. Объекты-аналоги: исходные данные")
    r += 1
    header_data_row = r
    obj_addr = "г. Иваново, ул. Гаражная, д.12/5"
    src_ref = ("Таблица 46; Таблица 65", "44; 56") if kind == "sale" else ("Таблица 69; Таблица 83", "64; 73")
    row("Источник информации", "", ["Данные Заказчика"] + [a["source"] for a in data["analogs"]],
        report_table=src_ref[0], report_page=src_ref[1], clause="22" if kind == "sale" else "23")
    row("Адрес объекта", "", [obj_addr] + [a["address"] for a in data["analogs"]],
        report_table=src_ref[0], report_page=src_ref[1], clause="22" if kind == "sale" else "23")
    area_ref = ("Таблица 46; Таблица 65", "44; 56") if kind == "sale" else ("Таблица 69; Таблица 83", "64; 73")
    area_row = row("Общая площадь, кв.м", "кв. м", ["", "", "", ""],
                   report_table=area_ref[0], report_page=area_ref[1],
                   clause="22" if kind == "sale" else "23")
    # заполнить площади и цены явно
    if kind == "sale":
        _write_value(ws, area_row, 4, "{{I_AREA}}", registry)
        for j, aid in enumerate(("I_S1_AREA", "I_S2_AREA", "I_S3_AREA"), start=5):
            _write_value(ws, area_row, j, "{{%s}}" % aid, registry)
        land_row = row("Площадь земельного участка, кв.м", "кв. м", ["", "", "", ""],
                       report_table="Таблица 46; Таблица 59", report_page="44; 53", clause="22")
        _write_value(ws, land_row, 4, "{{I_LAND}}", registry)
        for j, aid in enumerate(("I_S1_LAND", "I_S2_LAND", "I_S3_LAND"), start=5):
            _write_value(ws, land_row, j, "{{%s}}" % aid, registry)
        price_row = row("Цена предложения, руб.", "руб.", ["", "", "", ""],
                        report_table="Таблица 46", report_page=44, clause="22")
        for j, aid in enumerate(("I_S1_PRICE", "I_S2_PRICE", "I_S3_PRICE"), start=5):
            _write_value(ws, price_row, j, "{{%s}}" % aid, registry)
        rate_row = row("Цена предложения, руб./кв.м", "руб.", ["", "", "", ""],
                       report_table="Таблица 46", report_page=44, clause="22")
        for j, col in enumerate(("E", "F", "G"), start=5):
            ws.cell(row=rate_row, column=j, value=f"=ROUND({col}{price_row}/{col}{area_row},0)")
    else:
        _write_value(ws, area_row, 4, "{{I_AREA}}", registry)
        for j, aid in enumerate(("I_R1_AREA", "I_R2_AREA", "I_R3_AREA"), start=5):
            _write_value(ws, area_row, j, "{{%s}}" % aid, registry)
        rent_row = row("Арендная плата, руб./мес.", "руб./мес", ["", "", "", ""],
                       report_table="Таблица 69", report_page=64, clause="23")
        for j, aid in enumerate(("I_R1_RENT", "I_R2_RENT", "I_R3_RENT"), start=5):
            _write_value(ws, rent_row, j, "{{%s}}" % aid, registry)
        rate_row = row("Арендная ставка, руб./кв.м/мес", "руб./кв.м/мес", ["", "", "", ""],
                       report_table="Таблица 69", report_page=64, clause="23")
        for j, col in enumerate(("E", "F", "G"), start=5):
            ws.cell(row=rate_row, column=j, value=f"=ROUND({col}{rent_row}/{col}{area_row},0)")

    # Корректировки
    style_section(ws, r, 1, 12, "2. Корректировки")
    r += 1
    prev_row = rate_row
    pct_rows: list[int] = []
    excluded_rows: set[int] = set()
    coef_rows: list[int] = []

    for adj in data["adjustments"]:
        # В data/model.json для элемента сравнения задано четыре значения (объект и три аналога)
        # либо три (только аналоги, например торг). Значения пишутся с колонки D, поэтому
        # при трех значениях впереди остается пустая ячейка объекта.
        texts = list(adj.get("texts", []))
        if len(texts) < 4:
            texts = [""] * (4 - len(texts)) + texts
        row(adj["label"], "", texts, ref_table=adj.get("ref_table", ""),
            ref_page=adj.get("ref_page", ""), report_table=adj.get("report_table", ""),
            report_page=adj.get("report_page", ""), clause=adj.get("clause", "22"))
        kind_adj = adj.get("kind", "zero")
        coef_row = None
        if kind_adj == "ratio":
            coef_row = row(adj.get("coef_label", "Коэффициент корректировки"), "к-т",
                           ["", "", "", ""], ref_table=adj.get("ref_table", ""),
                           ref_page=adj.get("ref_page", ""), report_table=adj.get("report_table", ""),
                           report_page=adj.get("report_page", ""), clause=adj.get("clause", "22"))
            coef_rows.append(coef_row)
            _write_value(ws, coef_row, 4, formula_or_number(adj["object_coef"], registry), registry)
            for j, v in enumerate(adj["analog_coefs"], start=5):
                _write_value(ws, coef_row, j, formula_or_number(v, registry), registry)
            for j in range(4, 8):
                ws.cell(row=coef_row, column=j).number_format = "0.0000"
        pct_row = row("Корректировка, %", "%", ["", "", "", ""],
                      ref_table=adj.get("ref_table", ""), ref_page=adj.get("ref_page", ""),
                      report_table=adj.get("report_table", ""), report_page=adj.get("report_page", ""),
                      clause=adj.get("clause", "22"))
        pct_rows.append(pct_row)
        if adj.get("exclude"):
            excluded_rows.add(pct_row)
        if kind_adj == "ratio":
            shares = adj.get("shares") or ["1", "1", "1"]
            for j, col in enumerate(("E", "F", "G")):
                share = resolve(shares[j], registry)
                formula = f"=ROUND((D{coef_row}/{col}{coef_row}-1)*({share}),4)"
                ws.cell(row=pct_row, column=5 + j, value=formula)
        elif kind_adj == "direct":
            for j, f in enumerate(adj.get("percent_formulas", ["0", "0", "0"])):
                ws.cell(row=pct_row, column=5 + j, value=formula_or_number(f, registry))
        else:
            for j in range(5, 8):
                ws.cell(row=pct_row, column=j, value="=0")
        for j in range(5, 8):
            ws.cell(row=pct_row, column=j).number_format = "0.00%"
        rub_row = row("Корректировка, руб.", "руб.", ["", "", "", ""],
                      report_table=adj.get("report_table", ""), report_page=adj.get("report_page", ""),
                      clause=adj.get("clause", "22"))
        for j, col in enumerate(("E", "F", "G"), start=5):
            ws.cell(row=rub_row, column=j, value=f"=ROUND({col}{prev_row}*{col}{pct_row},0)")
            ws.cell(row=rub_row, column=j).number_format = "#,##0"
        adj_row = row("Скорректированная цена, руб./кв.м", "руб.", ["", "", "", ""],
                      report_table=adj.get("report_table", ""), report_page=adj.get("report_page", ""),
                      clause=adj.get("clause", "22"))
        for j, col in enumerate(("E", "F", "G"), start=5):
            ws.cell(row=adj_row, column=j, value=f"={col}{prev_row}+{col}{rub_row}")
            ws.cell(row=adj_row, column=j).number_format = "#,##0"
        prev_row = adj_row

    # Результаты
    style_section(ws, r, 1, 12, "3. Согласование скорректированных цен")
    r += 1
    included = [x for x in pct_rows if x not in excluded_rows]
    sum_row = row("Сумма процентных корректировок без учета торга (Si), %/100", "%", ["", "", "", ""],
                  report_table="Таблица 64" if kind == "sale" else "Таблица 82",
                  report_page=56 if kind == "sale" else 73, clause="22" if kind == "sale" else "23")
    for j, col in enumerate(("E", "F", "G"), start=5):
        parts = ",".join(f"ABS({col}{x})" for x in included)
        ws.cell(row=sum_row, column=j, value=f"=SUM({parts})")
        ws.cell(row=sum_row, column=j).number_format = "0.00%"
    inv_row = row("1/(1+Si)", "к-т", ["", "", "", ""],
                  report_table="Таблица 64" if kind == "sale" else "Таблица 82",
                  report_page=56 if kind == "sale" else 73, clause="22" if kind == "sale" else "23")
    inv_prec = int(data.get("inv_precision", 5))
    for j, col in enumerate(("E", "F", "G"), start=5):
        ws.cell(row=inv_row, column=j, value=f"=ROUND(1/(1+{col}{sum_row}),{inv_prec})")
        ws.cell(row=inv_row, column=j).number_format = "0." + "0" * inv_prec
    total_inv_row = row("Сумма 1/(1+Si)", "к-т", ["", "", "", ""],
                        report_table="Таблица 64" if kind == "sale" else "Таблица 82",
                        report_page=56 if kind == "sale" else 73, clause="22" if kind == "sale" else "23")
    ws.cell(row=total_inv_row, column=5, value=f"=SUM(E{inv_row}:G{inv_row})")
    ws.cell(row=total_inv_row, column=5).number_format = "0.000000"
    weights_row = row("Весовой коэффициент", "доля", ["", "", "", ""],
                      report_table="Таблица 64" if kind == "sale" else "Таблица 82",
                      report_page=56 if kind == "sale" else 73, clause="22" if kind == "sale" else "23")
    prec = int(data.get("weights_precision", 4))
    for j, col in enumerate(("E", "F", "G"), start=5):
        ws.cell(row=weights_row, column=j, value=f"=ROUND({col}{inv_row}/$E${total_inv_row},{prec})")
        ws.cell(row=weights_row, column=j).number_format = "0.00%"
    weights_sum_row = row("Сумма весов", "доля", ["", "", "", ""],
                          report_table="—", report_page="", clause="28")
    ws.cell(row=weights_sum_row, column=5, value=f"=SUM(E{weights_row}:G{weights_row})")
    ws.cell(row=weights_sum_row, column=5).number_format = "0.0000%"
    contrib_row = row("Вклад в стоимость, руб./кв.м", "руб.", ["", "", "", ""],
                      report_table="Таблица 64" if kind == "sale" else "Таблица 82",
                      report_page=56 if kind == "sale" else 73, clause="22" if kind == "sale" else "23")
    for j, col in enumerate(("E", "F", "G"), start=5):
        ws.cell(row=contrib_row, column=j, value=f"=ROUND({col}{prev_row}*{col}{weights_row},0)")
        ws.cell(row=contrib_row, column=j).number_format = "#,##0"
    avg_row = row("Средневзвешенное значение (цена 1 кв.м)", "руб.", ["", "", "", ""],
                  report_table="Таблица 64" if kind == "sale" else "Таблица 82",
                  report_page=56 if kind == "sale" else 73, clause="22" if kind == "sale" else "23")
    ws.cell(row=avg_row, column=5, value=f"=SUM(E{contrib_row}:G{contrib_row})")
    ws.cell(row=avg_row, column=5).number_format = "#,##0"
    result_row = avg_row
    if kind == "sale":
        eon_row = row("Рыночная стоимость ЕОН, руб.", "руб.", ["", "", "", ""],
                      report_table="Таблица 65", report_page=59, clause="22")
        ws.cell(row=eon_row, column=5, value=f"=ROUND(E{avg_row}*Вход!$F${registry.rows['I_AREA']},0)")
        ws.cell(row=eon_row, column=5).number_format = "#,##0"
        oks_row = row("Рыночная стоимость ОКС, руб.", "руб.", ["", "", "", ""],
                      report_table="Таблица 66", report_page=59, clause="22")
        ws.cell(row=oks_row, column=5, value=f"=ROUND(E{eon_row}*(1-Вход!$F${registry.rows['I_LAND_SHARE']}),0)")
        ws.cell(row=oks_row, column=5).number_format = "#,##0"
    cv_row = row("Коэффициент вариации", "%", ["", "", "", ""],
                 report_table="текст", report_page=59 if kind == "sale" else 76,
                 clause="22" if kind == "sale" else "23")
    ws.cell(row=cv_row, column=5, value=f"=STDEV(E{prev_row}:G{prev_row})/AVERAGE(E{prev_row}:G{prev_row})")
    ws.cell(row=cv_row, column=5).number_format = "0.00%"

    # Блок сверки
    r += 1
    style_section(ws, r, 1, 9, "4. Сверка результатов листа с отчетом")
    r += 1
    verif_header = r
    for i, h in enumerate(["Показатель", "Расчет", "Отчет", "Разница", "Последний разряд",
                           "Допуск", "Флаг", "Пункт ФСО 7", "Стр."], start=1):
        ws.cell(row=r, column=i, value=h)
    style_header(ws, r, 1, 9)
    r += 1
    verif_start = r

    rep = data.get("report", {})
    prec_map = {
        "price_sqm": 1, "adjusted": rep.get("precision_adjusted", 1),
        "sum_percent": rep.get("precision_percent", 0.0001),
        "weights": rep.get("precision_weight", 0.0001),
        "average": rep.get("precision_average", 1),
        "cv": rep.get("precision_cv", 0.0001),
    }
    if kind == "sale":
        prec_map["eon"] = rep.get("precision_eon", 1)
        prec_map["oks"] = rep.get("precision_oks", 1)
    for j, a in enumerate(data["analogs"]):
        col = ("E", "F", "G")[j]
        rep_sqm = a.get("report_rate" if kind == "rent" else "report_price_sqm")
        ws.cell(row=r, column=1, value=f"{a['name']}: цена 1 кв.м")
        ws.cell(row=r, column=2, value=f"={col}{rate_row}")
        ws.cell(row=r, column=3, value=rep_sqm)
        ws.cell(row=r, column=4, value=f"=B{r}-C{r}")
        ws.cell(row=r, column=5, value=a.get("precision_rate" if kind == "rent" else "precision_price_sqm", 1))
        ws.cell(row=r, column=6, value=f"=E{r}/2")
        ws.cell(row=r, column=7, value=f'=IF(ABS(D{r})<=F{r},"совпадает","расхождение")')
        ws.cell(row=r, column=8, value="22" if kind == "sale" else "23")
        ws.cell(row=r, column=9, value=44 if kind == "sale" else 64)
        for c in range(1, 10):
            cell = ws.cell(row=r, column=c)
            cell.border = BORDER
            cell.font = Font(name=FONT, size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        ws.cell(row=r, column=2).number_format = "#,##0"
        ws.cell(row=r, column=3).number_format = "#,##0"
        ws.cell(row=r, column=4).number_format = "#,##0.00"
        ws.cell(row=r, column=5).number_format = "0.####"
        ws.cell(row=r, column=6).number_format = "0.####"
        r += 1
    for j, a in enumerate(data["analogs"]):
        col = ("E", "F", "G")[j]
        ws.cell(row=r, column=1, value=f"{a['name']}: скорректированная цена")
        ws.cell(row=r, column=2, value=f"={col}{prev_row}")
        ws.cell(row=r, column=3, value=rep["adjusted"][j])
        ws.cell(row=r, column=4, value=f"=B{r}-C{r}")
        ws.cell(row=r, column=5, value=prec_map["adjusted"])
        ws.cell(row=r, column=6, value=f"=E{r}/2")
        ws.cell(row=r, column=7, value=f'=IF(ABS(D{r})<=F{r},"совпадает","расхождение")')
        ws.cell(row=r, column=8, value="22" if kind == "sale" else "23")
        ws.cell(row=r, column=9, value=58 if kind == "sale" else 76)
        for c in range(1, 10):
            cell = ws.cell(row=r, column=c)
            cell.border = BORDER
            cell.font = Font(name=FONT, size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        ws.cell(row=r, column=2).number_format = "#,##0"
        ws.cell(row=r, column=3).number_format = "#,##0"
        ws.cell(row=r, column=4).number_format = "#,##0.00"
        ws.cell(row=r, column=5).number_format = "0.####"
        ws.cell(row=r, column=6).number_format = "0.####"
        r += 1
    # суммы %, веса, среднее, CV, EON/OKS
    extra = [
        ("Сумма процентных корректировок, аналог 1", f"=E{sum_row}", rep["sum_percent"][0], "sum_percent", 59 if kind == "sale" else 76),
        ("Сумма процентных корректировок, аналог 2", f"=F{sum_row}", rep["sum_percent"][1], "sum_percent", 59 if kind == "sale" else 76),
        ("Сумма процентных корректировок, аналог 3", f"=G{sum_row}", rep["sum_percent"][2], "sum_percent", 59 if kind == "sale" else 76),
        ("Вес аналога 1", f"=E{weights_row}", rep["weights"][0], "weights", 56 if kind == "sale" else 76),
        ("Вес аналога 2", f"=F{weights_row}", rep["weights"][1], "weights", 56 if kind == "sale" else 76),
        ("Вес аналога 3", f"=G{weights_row}", rep["weights"][2], "weights", 56 if kind == "sale" else 76),
        ("Средневзвешенная цена 1 кв.м", f"=E{avg_row}", rep["average"], "average", 59 if kind == "sale" else 76),
        ("Коэффициент вариации", f"=E{cv_row}", rep["cv"], "cv", 60 if kind == "sale" else 77),
    ]
    if kind == "sale":
        extra += [
            ("Рыночная стоимость ЕОН", f"=E{eon_row}", rep["eon"], "eon", 59),
            ("Рыночная стоимость ОКС", f"=E{oks_row}", rep["oks"], "oks", 59),
        ]
    for label, formula, report_value, prec_key, page in extra:
        ws.cell(row=r, column=1, value=label)
        ws.cell(row=r, column=2, value=formula)
        ws.cell(row=r, column=3, value=report_value)
        ws.cell(row=r, column=4, value=f"=B{r}-C{r}")
        ws.cell(row=r, column=5, value=prec_map[prec_key])
        ws.cell(row=r, column=6, value=f"=E{r}/2")
        ws.cell(row=r, column=7, value=f'=IF(ABS(D{r})<=F{r},"совпадает","расхождение")')
        ws.cell(row=r, column=8, value="22" if kind == "sale" else "23")
        ws.cell(row=r, column=9, value=page)
        for c in range(1, 10):
            cell = ws.cell(row=r, column=c)
            cell.border = BORDER
            cell.font = Font(name=FONT, size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        ws.cell(row=r, column=2).number_format = "0.00%" if prec_key in ("sum_percent", "weights", "cv") else "#,##0.00"
        ws.cell(row=r, column=3).number_format = "0.00%" if prec_key in ("sum_percent", "weights", "cv") else "#,##0"
        ws.cell(row=r, column=4).number_format = "0.00%" if prec_key in ("sum_percent", "weights", "cv") else "#,##0.00"
        ws.cell(row=r, column=5).number_format = "0.#####"
        ws.cell(row=r, column=6).number_format = "0.#####"
        r += 1
    verif_end = r - 1
    ws.conditional_formatting.add(f"G{verif_start}:G{verif_end}",
                                  CellIsRule(operator="equal", formula=['"расхождение"'],
                                             fill=PatternFill("solid", fgColor=CLR_BAD)))
    ws.freeze_panes = "A5"

    # расчетные ячейки для check
    calc_ranges = []
    # строки исходных данных
    calc_ranges.append(f"D{area_row}:G{area_row}")
    if kind == "sale":
        calc_ranges.append(f"D{land_row}:G{land_row}")
        calc_ranges.append(f"E{price_row}:G{price_row}")
    else:
        calc_ranges.append(f"E{rent_row}:G{rent_row}")
    calc_ranges.append(f"E{rate_row}:G{rate_row}")
    for cr in coef_rows:
        calc_ranges.append(f"D{cr}:G{cr}")
    for pr in pct_rows:
        calc_ranges.append(f"E{pr}:G{pr}")
        calc_ranges.append(f"E{pr+1}:G{pr+1}")
        calc_ranges.append(f"E{pr+2}:G{pr+2}")
    calc_ranges += [f"E{sum_row}:G{sum_row}", f"E{inv_row}:G{inv_row}",
                    f"E{total_inv_row}:G{total_inv_row}", f"E{weights_row}:G{weights_row}",
                    f"E{weights_sum_row}:G{weights_sum_row}", f"E{contrib_row}:G{contrib_row}",
                    f"E{avg_row}:G{avg_row}", f"E{cv_row}:G{cv_row}"]
    if kind == "sale":
        calc_ranges += [f"E{eon_row}:G{eon_row}", f"E{oks_row}:G{oks_row}"]

    return {
        "sheet": data["sheet"],
        "rate_row": rate_row, "prev_row": prev_row,
        "weights_row": weights_row, "weight_sum_row": weights_sum_row,
        "avg_row": avg_row, "cv_row": cv_row,
        "eon_row": eon_row if kind == "sale" else None,
        "oks_row": oks_row if kind == "sale" else None,
        "verif_start": verif_start, "verif_end": verif_end,
        "calc_ranges": calc_ranges,
        "weight_cells": f"E{weights_row}:G{weights_row}",
        "flag_cells": f"G{verif_start}:G{verif_end}",
        "report_cells": f"C{verif_start}:C{verif_end}",
    }


# ---------------------------------------------------------------------------
# Лист «Расчет»
# ---------------------------------------------------------------------------

def build_calc_sheet(wb: Workbook, model: dict, registry: InputRegistry,
                     sale: dict, rent: dict) -> dict:
    ws = wb.create_sheet("Расчет")
    ws.sheet_view.showGridLines = False
    set_widths(ws, {"A": 5, "B": 62, "C": 12, "D": 18, "E": 18, "F": 14, "G": 11,
                    "H": 11, "I": 14, "J": 34, "K": 9, "L": 9, "M": 40})
    ws.merge_cells("A1:M1")
    c = ws["A1"]
    c.value = "РАСЧЕТ — модель стоимости, числа отчета только для сверки"
    c.font = Font(name=FONT, bold=True, size=14, color=CLR_HEADER)
    c.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 26
    ws.merge_cells("A2:M2")
    c = ws["A2"]
    c.value = ("В колонке «Расчет» только формулы; в колонке «Отчет» — напечатанное число; "
               "разница, допуск (половина последнего разряда) и флаг считаются формулами.")
    c.font = Font(name=FONT, italic=True, size=9, color="404040")
    c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    ws.row_dimensions[2].height = 28

    header_row = 4
    headers = ["№", "Показатель", "Ед. изм.", "Расчет", "Отчет", "Разница",
               "Последний разряд", "Допуск", "Флаг", "Формула / пояснение",
               "Пункт ФСО 7", "Стр. отчета", "Примечание"]
    for i, h in enumerate(headers, start=1):
        ws.cell(row=header_row, column=i, value=h)
    style_header(ws, header_row, 1, 13)

    r = header_row + 1
    num = 0
    calc_cells: list[str] = []
    flag_cells: list[str] = []
    report_cells: list[str] = []

    def add(label: str, unit: str, formula: str, report_value: Any, precision: Any,
            clause: str, page: Any, explanation: str = "", note: str = "",
            text_value: bool = False) -> int:
        nonlocal r, num
        num += 1
        ws.cell(row=r, column=1, value=num)
        ws.cell(row=r, column=2, value=label)
        ws.cell(row=r, column=3, value=unit)
        ws.cell(row=r, column=4, value=formula)
        ws.cell(row=r, column=5, value=report_value)
        if report_value is not None and not isinstance(report_value, str) and precision is not None:
            ws.cell(row=r, column=6, value=f"=D{r}-E{r}")
            ws.cell(row=r, column=7, value=precision)
            ws.cell(row=r, column=8, value=f"=G{r}/2")
            ws.cell(row=r, column=9, value=f'=IF(ABS(F{r})<=H{r},"совпадает","расхождение")')
            calc_cells.append(f"D{r}")
            flag_cells.append(f"I{r}")
            report_cells.append(f"E{r}")
        else:
            ws.cell(row=r, column=6, value="—")
            ws.cell(row=r, column=7, value="—")
            ws.cell(row=r, column=8, value="—")
            ws.cell(row=r, column=9, value="не применимо")
            if isinstance(report_value, str):
                report_cells.append(f"E{r}")
        if isinstance(explanation, str) and explanation.startswith("="):
            explanation = " " + explanation
        ws.cell(row=r, column=10, value=explanation)
        ws.cell(row=r, column=11, value=clause)
        ws.cell(row=r, column=12, value=page)
        ws.cell(row=r, column=13, value=note)
        style_row(ws, r, 1, 13, wrap=True)
        ws.cell(row=r, column=4).fill = PatternFill("solid", fgColor=CLR_CHECK)
        ws.cell(row=r, column=4).font = Font(name=FONT, size=10, bold=True)
        ws.cell(row=r, column=5).fill = PatternFill("solid", fgColor=CLR_REPORT)
        if precision is not None and isinstance(precision, (int, float)):
            if unit in ("доля", "%"):
                n = max(2, int(round(-math.log10(float(precision))))) if precision < 1 else 2
                fmt = "0." + "0" * n + "%"
            elif precision >= 1:
                fmt = "#,##0"
            else:
                n = max(0, int(round(-math.log10(float(precision)))))
                fmt = "#,##0." + "0" * n
            ws.cell(row=r, column=4).number_format = fmt
            ws.cell(row=r, column=5).number_format = fmt
            ws.cell(row=r, column=6).number_format = fmt
        ws.row_dimensions[r].height = 30
        r += 1
        return r - 1

    def section(title: str) -> None:
        nonlocal r
        style_section(ws, r, 1, 13, title)
        r += 1

    # 1. Доходный подход
    section("1. Доходный подход (п. 23 ФСО 7): от расчетной стоимости единого объекта")
    inc = model["calc"]["income"]
    rep = inc["report"]
    pr = inc["precision"]
    area_row = add("Общая площадь объекта оценки", "кв. м", f"='Вход'!$F${registry.rows['I_AREA']}",
                   rep["area"], pr["area"], "23", 56, "Вход!F", "Площадь из отчета")
    land_row = add("Площадь земельного участка", "кв. м", f"='Вход'!$F${registry.rows['I_LAND']}",
                   rep["land"], pr["land"], "22", 53, "Вход!F", "Площадь ЗУ")
    coef_row = add("Коэффициент арендопригодной площади", "к-т", f"='Вход'!$F${registry.rows['I_RENTABLE_COEF']}",
                   rep["rentable_coef"], pr["rentable_coef"], "23", 62, "Вход!F")
    rentable_row = add("Арендопригодная площадь", "кв. м", f"=ROUND(D{area_row}*D{coef_row},1)",
                       rep["rentable_area"], pr["rentable_area"], "23", 62, "=ROUND(площадь*коэф.,1)")
    rate_row = add("Действующая ставка аренды", "руб./кв.м/мес", "='Вход'!$D$8",
                   rep["rate"], pr["rate"], "23", 77, "Вход!D8", "Расчетная или ручная по переключателю")
    annual_row = add("Арендная ставка в год", "руб./кв.м/год", f"=D{rate_row}*12",
                     rep["annual_rate"], pr["annual_rate"], "23", 77, "=ставка*12")
    pvd_row = add("Потенциальный валовый доход (ПВД)", "руб./год", f"=ROUND(D{rentable_row}*D{annual_row},0)",
                  rep["pvd"], pr["pvd"], "23", 77, "=арендопригодная площадь*годовая ставка")
    vac_row = add("Коэффициент недозагрузки", "доля", f"='Вход'!$F${registry.rows['I_VACANCY']}",
                  rep["vacancy"], pr["vacancy"], "23", 77, "Вход!F")
    load_row = add("Коэффициент загрузки", "доля", f"=1-D{vac_row}",
                   rep["load"], pr["load"], "23", 77, "=1-недозагрузка")
    vod_row = add("Валовый операционный доход (ВОД)", "руб./год", f"=ROUND(D{pvd_row}*D{load_row},0)",
                  rep["vod"], pr["vod"], "23", 78, "=ПВД*загрузка")
    opex_row = add("Доля операционных расходов", "доля", f"='Вход'!$F${registry.rows['I_OPEX']}",
                   rep["opex"], pr["opex"], "23", 78, "Вход!F")
    opex_amt_row = add("Операционные расходы", "руб./год", f"=ROUND(D{pvd_row}*D{opex_row},0)",
                       rep["opex_amount"], pr["opex_amount"], "23", 78, "=ПВД*доля расходов")
    noi_row = add("Чистый операционный доход (ЧОД)", "руб./год", f"=D{vod_row}-D{opex_amt_row}",
                  rep["noi"], pr["noi"], "23", 78, "=ВОД-расходы")
    cap_row = add("Ставка капитализации", "доля", f"='Вход'!$F${registry.rows['I_CAP_RATE']}",
                  rep["cap_rate"], pr["cap_rate"], "23", 78, "Вход!F")
    eon_inc_row = add("Рыночная стоимость ЕОН (доходный подход)", "руб.", f"=ROUND(D{noi_row}/D{cap_row},0)",
                      rep["eon"], pr["eon"], "23", 79, "=ЧОД/ставка капитализации", "Расчетная стоимость единого объекта")
    share_row = add("Доля земельного участка в стоимости ЕОН", "доля", f"='Вход'!$F${registry.rows['I_LAND_SHARE']}",
                    rep["land_share"], pr["land_share"], "23", 79, "Вход!F")
    oks_inc_row = add("Рыночная стоимость ОКС (доходный подход)", "руб.", f"=ROUND(D{eon_inc_row}*(1-D{share_row}),0)",
                      rep["oks"], pr["oks"], "23", 79, "=ЕОН*(1-доля ЗУ)", "Выделение ОКС из расчетной стоимости ЕОН")

    # 2. Сравнительный подход
    section("2. Сравнительный подход (п. 22 ФСО 7): результат листа «Продажа»")
    comp = model["calc"]["comparative"]
    crep = comp["report"]
    cpr = comp["precision"]
    adj_rows = []
    for j, name in enumerate(("Аналог 1", "Аналог 2", "Аналог 3")):
        col = ("E", "F", "G")[j]
        adj_rows.append(add(f"{name}: скорректированная цена", "руб./кв.м",
                            f"='Продажа'!{col}{sale['prev_row']}",
                            crep["adjusted"][j], cpr["adjusted"], "22", 58,
                            f"Продажа!{col}{sale['prev_row']}"))
    weight_rows = []
    for j, name in enumerate(("Аналог 1", "Аналог 2", "Аналог 3")):
        col = ("E", "F", "G")[j]
        weight_rows.append(add(f"{name}: вес", "доля", f"='Продажа'!{col}{sale['weights_row']}",
                               crep["weights"][j], cpr["weights"], "22", 59,
                               f"Продажа!{col}{sale['weights_row']}"))
    comp_avg_row = add("Средневзвешенная цена 1 кв.м (сравнительный подход)", "руб./кв.м",
                       f"='Продажа'!E{sale['avg_row']}", crep["average"], cpr["average"], "22", 59,
                       f"Продажа!E{sale['avg_row']}")
    comp_eon_row = add("Рыночная стоимость ЕОН (сравнительный подход)", "руб.",
                       f"='Продажа'!E{sale['eon_row']}", crep["eon"], cpr["eon"], "22", 59,
                       f"Продажа!E{sale['eon_row']}")
    comp_oks_row = add("Рыночная стоимость ОКС (сравнительный подход)", "руб.",
                       f"='Продажа'!E{sale['oks_row']}", crep["oks"], cpr["oks"], "22", 59,
                       f"Продажа!E{sale['oks_row']}")
    cv_row = add("Коэффициент вариации (сравнительный подход)", "%",
                 f"='Продажа'!E{sale['cv_row']}", crep["cv"], cpr["cv"], "22", 60,
                 f"Продажа!E{sale['cv_row']}")

    # 3. Затратный подход
    section("3. Затратный подход (п. 24 ФСО 7): отказ с обоснованием")
    cost = model["calc"]["cost"]
    cost_row = add("Рыночная стоимость ОКС (затратный подход)", "руб.", "=0",
                   cost["report_value"], 1, "24", 81,
                   "=0", "Затратный подход не применялся")
    # строка обоснования
    num += 1
    ws.cell(row=r, column=1, value=num)
    ws.cell(row=r, column=2, value="Обоснование отказа от затратного подхода")
    ws.cell(row=r, column=3, value="—")
    ws.cell(row=r, column=4, value='="не применялся"')
    ws.cell(row=r, column=5, value="не применялся")
    ws.cell(row=r, column=6, value="—")
    ws.cell(row=r, column=7, value="—")
    ws.cell(row=r, column=8, value="—")
    ws.cell(row=r, column=9, value="не применимо")
    ws.cell(row=r, column=10, value="Рынок развит; объект не специального назначения")
    ws.cell(row=r, column=11, value="24")
    ws.cell(row=r, column=12, value=cost["page"])
    ws.cell(row=r, column=13, value=cost["justification"])
    style_row(ws, r, 1, 13, wrap=True)
    ws.cell(row=r, column=4).fill = PatternFill("solid", fgColor=CLR_CHECK)
    ws.row_dimensions[r].height = 44
    r += 1

    # 4. Согласование
    section("4. Согласование результатов (п. 28 ФСО 7)")
    recon = model["calc"]["reconciliation"]
    rrep = recon["report"]
    rpr = recon["precision"]
    comp_value_row = add("Стоимость по сравнительному подходу", "руб.", f"=D{comp_oks_row}",
                         rrep["comp_value"], rpr["comp_value"], "28", 85, f"=Расчет!D{comp_oks_row}")
    comp_weight_row = add("Вес сравнительного подхода", "доля", f"='Вход'!$F${registry.rows['I_WEIGHT_SALE_COMP']}",
                          rrep["comp_weight"], rpr["comp_weight"], "28", 85, "Вход!F")
    comp_contrib_row = add("Вклад сравнительного подхода", "руб.", f"=ROUND(D{comp_value_row}*D{comp_weight_row},0)",
                           rrep["comp_contrib"], rpr["comp_contrib"], "28", 85, "=стоимость*вес")
    inc_value_row = add("Стоимость по доходному подходу", "руб.", f"=D{oks_inc_row}",
                        rrep["inc_value"], rpr["inc_value"], "28", 85, f"=Расчет!D{oks_inc_row}")
    inc_weight_row = add("Вес доходного подхода", "доля", f"='Вход'!$F${registry.rows['I_WEIGHT_SALE_INC']}",
                         rrep["inc_weight"], rpr["inc_weight"], "28", 85, "Вход!F")
    inc_contrib_row = add("Вклад доходного подхода", "руб.", f"=ROUND(D{inc_value_row}*D{inc_weight_row},0)",
                          rrep["inc_contrib"], rpr["inc_contrib"], "28", 85, "=стоимость*вес")
    cost_value_row = add("Стоимость по затратному подходу", "руб.", f"=D{cost_row}",
                         rrep["cost_value"], rpr["cost_value"], "28", 85, f"=Расчет!D{cost_row}")
    cost_weight_row = add("Вес затратного подхода", "доля", f"='Вход'!$F${registry.rows['I_WEIGHT_COST']}",
                          rrep["cost_weight"], rpr["cost_weight"], "28", 85, "Вход!F")
    cost_contrib_row = add("Вклад затратного подхода", "руб.", f"=ROUND(D{cost_value_row}*D{cost_weight_row},0)",
                           rrep["cost_contrib"], rpr["cost_contrib"], "28", 85, "=стоимость*вес")
    sum_weights_row = add("Сумма весов подходов", "доля", f"=SUM(D{comp_weight_row},D{inc_weight_row},D{cost_weight_row})",
                          rrep["sum_weights"], rpr["sum_weights"], "28", 85, "=сумма весов")
    weighted_row = add("Средневзвешенная стоимость", "руб.", f"=SUM(D{comp_contrib_row},D{inc_contrib_row},D{cost_contrib_row})",
                       rrep["weighted"], rpr["weighted"], "28", 85, "=сумма вкладов")
    step_row = add("Шаг округления", "руб.", f"='Вход'!$D$9",
                   rrep["step"], rpr["step"], "28", 85, "Вход!D9", "Шаг из листа «Вход»")
    final_row = add("Итоговая стоимость (округленно)", "руб.", f"=ROUND(D{weighted_row}/D{step_row},0)*D{step_row}",
                    rrep["final"], rpr["final"], "28", 85, "=ROUND(средневзвешенная/шаг,0)*шаг", "Итог формулы округления")

    # 5. Интервал
    section("5. Интервал стоимости (п. 30 ФСО 7)")
    interval = model["calc"]["interval"]
    if interval.get("required"):
        add("Нижняя граница интервала", "руб.", "=0", None, None, "30", interval.get("page", ""),
            "задается моделью", "Интервал задается в model.json")
        add("Верхняя граница интервала", "руб.", "=0", None, None, "30", interval.get("page", ""),
            "задается моделью", "Интервал задается в model.json")
    else:
        num += 1
        ws.cell(row=r, column=1, value=num)
        ws.cell(row=r, column=2, value="Интервал стоимости")
        ws.cell(row=r, column=3, value="—")
        ws.cell(row=r, column=4, value='="не приводится"')
        ws.cell(row=r, column=5, value="не приводится")
        ws.cell(row=r, column=6, value="—")
        ws.cell(row=r, column=7, value="—")
        ws.cell(row=r, column=8, value="—")
        ws.cell(row=r, column=9, value="не применимо")
        ws.cell(row=r, column=10, value=interval.get("reason", ""))
        ws.cell(row=r, column=11, value="30")
        ws.cell(row=r, column=12, value=interval.get("page", ""))
        ws.cell(row=r, column=13, value=interval.get("quote", ""))
        style_row(ws, r, 1, 13, wrap=True)
        ws.cell(row=r, column=4).fill = PatternFill("solid", fgColor=CLR_CHECK)
        ws.row_dimensions[r].height = 44
        r += 1

    last_row = r - 1
    ws.conditional_formatting.add(f"I{header_row + 1}:I{last_row}",
                                  CellIsRule(operator="equal", formula=['"расхождение"'],
                                             fill=PatternFill("solid", fgColor=CLR_BAD)))
    ws.freeze_panes = "A5"

    return {
        "sheet": "Расчет", "last_row": last_row,
        "calc_cells": calc_cells, "flag_cells": flag_cells, "report_cells": report_cells,
        "income_oks_row": oks_inc_row, "comp_oks_row": comp_oks_row,
        "weighted_row": weighted_row, "final_row": final_row,
        "sum_weights_row": sum_weights_row,
    }


# ---------------------------------------------------------------------------
# Сборка книги
# ---------------------------------------------------------------------------

def build_book(model: dict, out_path: Path, inputs_override: dict | None = None) -> None:
    if inputs_override:
        by_id = {x["id"]: x for x in model["inputs"]}
        for key, rec in inputs_override.get("inputs", {}).items():
            if key in by_id:
                if rec.get("report_value") is not None:
                    by_id[key]["report_value"] = rec["report_value"]
                if rec.get("value") is not None:
                    by_id[key]["value"] = rec["value"]

    wb = Workbook()
    registry = InputRegistry(model)
    registry.write(wb)
    sale = build_analog_sheet(wb, model, registry, "sale")
    rent = build_analog_sheet(wb, model, registry, "rent")
    calc = build_calc_sheet(wb, model, registry, sale, rent)

    # подставить адрес расчетной ставки в лист «Вход»
    wb["Вход"]["D7"] = f"='Аренда'!E{rent['avg_row']}"

    # служебный лист с картой проверки
    meta = {
        "version": 1,
        "model": model.get("meta", {}),
        "calc_ranges": (
            [("Продажа", x) for x in sale["calc_ranges"]] +
            [("Аренда", x) for x in rent["calc_ranges"]] +
            [("Расчет", x) for x in calc["calc_cells"]]
        ),
        "report_ranges": (
            [("Вход", "G13:G%d" % registry.last_row),
             ("Расчет", "E5:E%d" % calc["last_row"]),
             ("Продажа", sale["report_cells"]),
             ("Аренда", rent["report_cells"])]
        ),
        "weights": [
            ("Продажа", sale["weight_cells"]),
            ("Аренда", rent["weight_cells"]),
            ("Расчет", f"D{calc['sum_weights_row']}"),
        ],
        "flags": [
            ("Вход", "K13:K%d" % registry.last_row),
            ("Продажа", sale["flag_cells"]),
            ("Аренда", rent["flag_cells"]),
            ("Расчет", "I5:I%d" % calc["last_row"]),
        ],
        "inputs": registry.meta_rows,
    }
    ws = wb.create_sheet("_meta")
    ws["A1"] = json.dumps(meta, ensure_ascii=False)
    ws["A2"] = "Служебный лист: карта расчета и проверки. Не править."
    ws.sheet_state = "veryHidden"

    setup_print(wb["Вход"], registry.last_row, 16, "11:12")
    setup_print(wb["Продажа"], wb["Продажа"].max_row, 12, "1:4")
    setup_print(wb["Аренда"], wb["Аренда"].max_row, 12, "1:4")
    setup_print(wb["Расчет"], calc["last_row"], 13, "1:4")

    wb.calculation.fullCalcOnLoad = True
    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
    print(f"собрано: {out_path}")
    print(f"листы: {', '.join(wb.sheetnames)}")
    print(f"входов: {len(model['inputs'])}; корректировок продажи: {len(model['sale']['adjustments'])}; "
          f"корректировок аренды: {len(model['rent']['adjustments'])}")


# ---------------------------------------------------------------------------
# Пересчет LibreOffice
# ---------------------------------------------------------------------------

def find_soffice() -> str | None:
    for name in ("soffice", "libreoffice"):
        p = shutil.which(name)
        if p:
            return p
    for p in ("/Applications/LibreOffice.app/Contents/MacOS/soffice",
              "/usr/bin/libreoffice", "/usr/bin/soffice"):
        if Path(p).exists():
            return p
    return None


def write_lo_profile(profile: Path) -> None:
    user = profile / "user"
    user.mkdir(parents=True, exist_ok=True)
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop></item>
 <item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="ODFRecalcMode" oor:op="fuse"><value>0</value></prop></item>
</oor:items>
"""
    (user / "registrymodifications.xcu").write_text(xml, encoding="utf-8")


def recalc_book(path: Path, timeout: int = 240) -> None:
    soffice = find_soffice()
    if not soffice:
        raise SystemExit("LibreOffice не найден: нужен soffice в PATH или в /Applications.")
    path = path.resolve()
    if not path.exists():
        raise SystemExit(f"Файл не найден: {path}")
    with tempfile.TemporaryDirectory(prefix="raschet_lo_") as td:
        td = Path(td)
        profile = td / "profile"
        write_lo_profile(profile)
        outdir = td / "out"
        outdir.mkdir()
        cmd = [soffice, f"-env:UserInstallation={profile.resolve().as_uri()}", "--headless",
               "--convert-to", "xlsx:Calc Office Open XML", "--outdir", str(outdir), str(path)]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if proc.returncode != 0:
            raise SystemExit(f"LibreOffice вернул {proc.returncode}:\n{proc.stdout}\n{proc.stderr}")
        produced = outdir / path.name
        if not produced.exists():
            candidates = list(outdir.glob("*.xlsx"))
            if not candidates:
                raise SystemExit(f"LibreOffice не создал файл:\n{proc.stdout}\n{proc.stderr}")
            produced = candidates[0]
        shutil.copy2(produced, path)
    print(f"пересчитано: {path}")


# ---------------------------------------------------------------------------
# Извлечение и проверка входов
# ---------------------------------------------------------------------------

def extract_inputs(model: dict, report_path: Path, out_json: Path | None = None,
                   out_md: Path | None = None) -> int:
    text = report_path.read_text(encoding="utf-8")
    pages = split_pages(text)
    rows = []
    bad = 0
    for item in model["inputs"]:
        page = item.get("page")
        quote = item.get("quote", "")
        page_text = pages.get(int(page), "") if page not in (None, "") else ""
        pv = norm_variants(page_text)
        qv = norm_variants(quote)[0]
        found = any(qv in x for x in pv)
        num, token = extract_closest_number(quote, float(item["value"]))
        status = "ok"
        if item.get("derived"):
            status = "производное значение"
            if not found:
                status = "цитата не найдена на странице"
                bad += 1
        elif not found:
            status = "цитата не найдена на странице"
            bad += 1
        elif num is None:
            status = "число в цитате не найдено"
            bad += 1
        else:
            prec = item.get("precision") or 0
            tol = max(float(prec) / 2.0, 1e-9)
            if abs(num - float(item["value"])) > tol:
                status = f"расхождение: в цитате {num}, в модели {item['value']}"
                bad += 1
        rows.append({
            "id": item["id"], "label": item.get("label", ""), "value": item.get("value"),
            "report_value": item.get("report_value") if item.get("derived") else (num if num is not None else item.get("report_value")),
            "quote": quote, "page": page, "status": status, "token": token,
        })
    if out_json:
        out_json.parent.mkdir(parents=True, exist_ok=True)
        out_json.write_text(json.dumps({"inputs": {x["id"]: x for x in rows}},
                                       ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"реестр входов: {out_json}")
    if out_md:
        out_md.parent.mkdir(parents=True, exist_ok=True)
        lines = ["# Реестр исходных чисел", "",
                 "| Код | Показатель | Значение | Стр. | Статус | Цитата |",
                 "| --- | --- | ---: | ---: | --- | --- |"]
        for x in rows:
            q = str(x["quote"]).replace("|", "\\|").replace("\n", " ")
            lines.append(f"| `{x['id']}` | {x['label']} | {x['value']} | {x['page']} | {x['status']} | {q} |")
        out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"реестр входов: {out_md}")
    print(f"проверено входов: {len(rows)}; замечаний: {bad}")
    if bad:
        for x in rows:
            if x["status"] != "ok":
                print(f"  ! {x['id']}: {x['status']}")
    return 0 if bad == 0 else 1


# ---------------------------------------------------------------------------
# Проверка книги
# ---------------------------------------------------------------------------

REF_RE = re.compile(
    r"(?:(?P<sheet>'[^']+'|[A-Za-zА-Яа-яЁё0-9_ ]+)!)?"
    r"(?P<start>\$?[A-Z]{1,3}\$?\d+)"
    r"(?::(?P<end>\$?[A-Z]{1,3}\$?\d+))?"
)


def _coord_tuple(coord: str) -> tuple[int, int]:
    coord = coord.replace("$", "")
    m = re.fullmatch(r"([A-Z]{1,3})(\d+)", coord)
    if not m:
        raise ValueError(coord)
    col = 0
    for ch in m.group(1):
        col = col * 26 + (ord(ch) - ord("A") + 1)
    return int(m.group(2)), col


def _expand_range(start: str, end: str | None) -> Iterable[str]:
    r1, c1 = _coord_tuple(start)
    if not end:
        yield f"{get_column_letter(c1)}{r1}"
        return
    r2, c2 = _coord_tuple(end)
    if abs(r2 - r1) * abs(c2 - c1) > 2000:
        return
    for rr in range(min(r1, r2), max(r1, r2) + 1):
        for cc in range(min(c1, c2), max(c1, c2) + 1):
            yield f"{get_column_letter(cc)}{rr}"


def formula_refs(formula: str, current_sheet: str) -> Iterable[tuple[str, str]]:
    s = re.sub(r'"(?:[^"]|"")*"', '""', formula)
    for m in REF_RE.finditer(s):
        sheet = m.group("sheet")
        if sheet:
            sheet = sheet.strip("'")
        else:
            sheet = current_sheet
        for coord in _expand_range(m.group("start"), m.group("end")):
            yield sheet, coord


def _range_contains(rng: str, cell: str) -> bool:
    try:
        c1, r1, c2, r2 = range_boundaries(rng.replace("$", ""))
    except Exception:
        return False
    cr, cc = _coord_tuple(cell)
    return r1 <= cr <= r2 and c1 <= cc <= c2


def _iter_range(ws, rng: str):
    """Перебрать ячейки диапазона или одной ячейки."""
    clean = rng.replace("$", "")
    if ":" in clean:
        c1, r1, c2, r2 = range_boundaries(clean)
    else:
        r1, c1 = _coord_tuple(clean)
        r2, c2 = r1, c1
    for row in ws.iter_rows(min_row=r1, max_row=r2, min_col=c1, max_col=c2):
        for cell in row:
            yield cell


def check_book(path: Path, report_path: Path | None = None) -> int:
    path = path.resolve()
    if not path.exists():
        raise SystemExit(f"Файл не найден: {path}")
    wbf = load_workbook(path, data_only=False, read_only=False)
    wbv = load_workbook(path, data_only=True, read_only=False)
    if "_meta" not in wbf.sheetnames:
        raise SystemExit("В книге нет служебного листа _meta: книга собрана не навыком.")
    meta = json.loads(wbf["_meta"]["A1"].value)
    # без пересчета в LibreOffice в книге нет вычисленных значений
    probe = wbv["Расчет"]["D6"].value
    if probe is None:
        print("Книга не пересчитана: выполните команду recalc, затем повторите check.")
        return 2
    issues: list[str] = []

    # 1. Веса
    print("== Сумма весов ==")
    for sheet, rng in meta.get("weights", []):
        vals = []
        for cell in _iter_range(wbv[sheet], rng):
            if isinstance(cell.value, (int, float)):
                vals.append(float(cell.value))
        s = sum(vals)
        print(f"{sheet}!{rng}: {s:.10g}  ({'OK' if abs(s - 1) <= 1e-8 else 'НЕ РАВНА 1'})")
        if abs(s - 1) > 1e-8:
            issues.append(f"Сумма весов {sheet}!{rng} = {s:.10g}, не 1")

    # 2-4. Расчетные ячейки
    empty_refs: list[str] = []
    non_formula: list[str] = []
    report_refs: list[str] = []
    seen_empty = set()
    seen_report = set()

    def is_report_cell(sheet: str, cell: str) -> bool:
        for rs, rr in meta.get("report_ranges", []):
            if rs == sheet and _range_contains(rr, cell):
                return True
        return False

    for sheet, rng in meta.get("calc_ranges", []):
        try:
            parts = rng.replace("$", "").split(":")
            cells = list(_expand_range(parts[0], parts[1] if len(parts) > 1 else None))
        except Exception:
            continue
        for cell in cells:
            fcell = wbf[sheet][cell]
            f = fcell.value
            if f is None:
                continue
            if not (isinstance(f, str) and f.startswith("=")):
                non_formula.append(f"{sheet}!{cell} = {f!r}")
                continue
            for ref_sheet, ref_cell in formula_refs(f, sheet):
                if ref_sheet not in wbf.sheetnames:
                    continue
                v = wbv[ref_sheet][ref_cell].value
                key = (sheet, cell, ref_sheet, ref_cell)
                if v is None or v == "":
                    if key not in seen_empty:
                        seen_empty.add(key)
                        empty_refs.append(f"{sheet}!{cell} -> {ref_sheet}!{ref_cell}")
                if is_report_cell(ref_sheet, ref_cell):
                    if key not in seen_report:
                        seen_report.add(key)
                        report_refs.append(f"{sheet}!{cell} -> {ref_sheet}!{ref_cell}")

    print("\n== Ссылки на пустые ячейки ==")
    if empty_refs:
        for x in empty_refs:
            print(" ! " + x)
        issues.extend(empty_refs)
    else:
        print("не найдено")

    print("\n== Числа вместо формул в расчетных ячейках ==")
    if non_formula:
        for x in non_formula:
            print(" ! " + x)
        issues.extend(non_formula)
    else:
        print("не найдено")

    print("\n== Ссылки расчетных ячеек на числа отчета ==")
    if report_refs:
        for x in report_refs:
            print(" ! " + x)
        issues.extend(report_refs)
    else:
        print("не найдено")

    # 5. Флаги расхождений
    print("\n== Флаги расхождений ==")
    bad_flags = []
    for sheet, rng in meta.get("flags", []):
        for cell in _iter_range(wbv[sheet], rng):
            if cell.value == "расхождение":
                r = cell.row
                ctx = []
                for c in range(1, 14):
                    v = wbv[sheet].cell(row=r, column=c).value
                    if v not in (None, ""):
                        ctx.append(f"{get_column_letter(c)}={v}")
                bad_flags.append(f"{sheet}!{cell.coordinate}: " + "; ".join(ctx))
    if bad_flags:
        for x in bad_flags:
            print(" ! " + x)
        issues.extend(bad_flags)
    else:
        print("не найдено")

    # 6. Цитаты и пункты
    print("\n== Цитаты и страницы ==")
    quote_bad = []
    if report_path and report_path.exists():
        pages = split_pages(report_path.read_text(encoding="utf-8"))
        ws_in = wbv["Вход"]
        for item in meta.get("inputs", []):
            row = item["row"]
            page = ws_in.cell(row=row, column=13).value or item.get("page")
            quote = ws_in.cell(row=row, column=12).value or item.get("quote", "")
            clause = str(ws_in.cell(row=row, column=15).value or item.get("clause", ""))
            pv = norm_variants(pages.get(int(page), "")) if page not in (None, "") else [""]
            qv = norm_variants(quote)[0]
            if not any(qv in x for x in pv):
                quote_bad.append(f"Вход!{row}: цитата не найдена на стр. {page} ({item.get('id')})")
            nums = [int(x) for x in re.findall(r"\d+", clause)]
            if not nums or any(n not in (22, 23, 24, 28, 30) for n in nums):
                quote_bad.append(f"Вход!{row}: пункт ФСО 7 «{clause}» вне 22/23/24/28/30")
        # пункты ФСО 7 в расчетных листах
        for sheet, col, first in (("Расчет", 11, 6), ("Продажа", 12, 5), ("Аренда", 12, 5)):
            ws = wbv[sheet]
            for r in range(first, ws.max_row + 1):
                clause = str(ws.cell(row=r, column=col).value or "").strip()
                if not clause:
                    continue
                nums = [int(x) for x in re.findall(r"\d+", clause)]
                if not nums or any(n not in (22, 23, 24, 28, 30) for n in nums):
                    quote_bad.append(f"{sheet}!{get_column_letter(col)}{r}: пункт ФСО 7 «{clause}» вне 22/23/24/28/30")
    else:
        print("текст отчета не найден, проверка цитат пропущена")
    if quote_bad:
        for x in quote_bad:
            print(" ! " + x)
        issues.extend(quote_bad)
    else:
        print("не найдено")

    print("\n== Итог ==")
    if issues:
        print(f"ЕСТЬ ЗАМЕЧАНИЯ: {len(issues)}")
        return 1
    print("ПРОВЕРКА ПРОЙДЕНА")
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Расчетный файл по отчету об оценке")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("extract", help="собрать реестр входов и проверить цитаты/страницы")
    p.add_argument("--model", type=Path, default=DEFAULT_MODEL)
    p.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    p.add_argument("--out", type=Path, default=Path("Склад/Результаты/raschet_inputs.json"))
    p.add_argument("--md", type=Path, default=None)

    p = sub.add_parser("build", help="записать книгу формулами")
    p.add_argument("--model", type=Path, default=DEFAULT_MODEL)
    p.add_argument("--out", type=Path, default=DEFAULT_OUT)
    p.add_argument("--inputs", type=Path, default=None,
                   help="JSON от команды extract для подстановки значений")

    p = sub.add_parser("recalc", help="пересчитать книгу в LibreOffice")
    p.add_argument("--file", type=Path, default=DEFAULT_OUT)
    p.add_argument("--timeout", type=int, default=240)

    p = sub.add_parser("check", help="проверить веса, ссылки, формулы и флаги")
    p.add_argument("--file", type=Path, default=DEFAULT_OUT)
    p.add_argument("--report", type=Path, default=DEFAULT_REPORT)

    args = ap.parse_args(argv)

    if args.cmd == "extract":
        model = json.loads(args.model.read_text(encoding="utf-8"))
        return extract_inputs(model, args.report, args.out, args.md)
    if args.cmd == "build":
        model = json.loads(args.model.read_text(encoding="utf-8"))
        override = None
        if args.inputs:
            override = json.loads(args.inputs.read_text(encoding="utf-8"))
        build_book(model, args.out, override)
        return 0
    if args.cmd == "recalc":
        recalc_book(args.file, args.timeout)
        return 0
    if args.cmd == "check":
        return check_book(args.file, args.report)
    return 2


if __name__ == "__main__":
    sys.exit(main())
